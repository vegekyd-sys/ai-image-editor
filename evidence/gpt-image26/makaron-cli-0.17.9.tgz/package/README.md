# Makaron CLI — Agent Integration Skill

> **makaron.app** is for humans. **makaron-cli** is for AI agents.

Makaron is a multimodal AI creative agent. You talk to it via `makaron chat`, and it produces images, videos, music, and animated designs — all saved to a persistent project.

## Setup

```bash
# Install makaron-cli globally and add the Makaron Agent Skill.
npx makaron-cli setup

npx makaron-cli --help
```

### Get your API key

**Option A: Human login**
1. Go to [makaron.app](https://makaron.app) and log in
2. Open the menu (top-right)
3. Click **Get API Key**
4. Copy your `mk_live_...` key

**Option B: Agent Self-Registration (no human required)**
```bash
# Step 1: Get challenge
npx makaron-cli register --json
# → { "challenge_id": "...", "challenge": "...", "expected_format": "numeric, round to 2 decimal places" }

# Step 2: Solve the math problem and verify
npx makaron-cli register --verify --challenge-id <id> --answer 34.5
# → Key saved to ~/.makaron/auth.json
# → { "api_key": "mk_live_...", "credits": N, "claim_url": "..." }
```

After registration, the key is saved locally — no need to export `MAKARON_API_KEY`.

Discovery endpoint (returns full registration flow + CLI usage as JSON):
```bash
curl https://www.makaron.app/api/agent/register
```

Docs: [makaron.app/agent](https://www.makaron.app/agent)

```bash
export MAKARON_API_KEY=mk_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

Verify: `npx makaron-cli list` should show projects.

Check the current credit balance and subscription:
```bash
npx makaron-cli credits
npx makaron-cli credits --json
```

Every `chat` prints the credits it used when it finishes (on stderr, e.g.
`💳  43 credits used (agent 24 · generate_image 19) · balance 1157`), and
`--json` results carry the same numbers in a `usage` object. To look it up later:
```bash
npx makaron-cli responses get <runId> --pick credits_used   # net credits of one run
npx makaron-cli usage --run <runId>                         # per-tool breakdown of one run
npx makaron-cli usage --limit 20                            # recent usage rows (all sources)
```

### Let a human claim your account

After registering, generate a link for a human to link your API key to their account:
```bash
npx makaron-cli claim
# → { "claim_url": "https://www.makaron.app/claim?token=clm_..." }
```
Share the `claim_url` with a human. They log in and the API key gets linked to their account. Claim links are valid for 7 days. Run `claim` again anytime to get a new link.

## Core Workflow

```bash
# One-shot: create project + upload image + submit prompt — all in one command
RUN_ID=$(npx makaron-cli chat --project auto --image photo.jpg -b "make it cinematic and create a 5s video")

# Wait for the final customer-ready result
npx makaron-cli responses get $RUN_ID --wait --json
```

Or with an existing project:
```bash
RUN_ID=$(npx makaron-cli chat --project $PROJECT_ID -b "make a 5s video")
npx makaron-cli responses get $RUN_ID --wait --json
```

## Primary: `chat` (Agent-driven creative work)

Use `chat` for all creative tasks. Makaron Agent decides how to execute — it can edit images, generate videos, compose music, and create designs in a single conversation.

```bash
npx makaron-cli chat --help
```

### Submit a request

```bash
# With existing project
npx makaron-cli chat --project <id> --json -b "<prompt>"

# Auto-create project (with or without images)
npx makaron-cli chat --project auto --image photo.jpg --json -b "make it cinematic"
npx makaron-cli chat --project auto --image img1.jpg --image img2.jpg --json -b "combine these"
```

`chat` routes image and video models automatically, but you may select the Agent LLM with `--agent-model`. Accepted values are `auto`, the base model IDs (`gpt-6-luna`, `gpt-6.1-sol`, `gpt-6-sol`, `gpt-5.6-terra`, `gpt-5.6-sol`, `gpt-5.6-luna`, `grok-4.6`, `deepseek-v4-pro`, `deepseek-flash`), and the personal-plan routes (`gpt-6-luna-codex-subscription`, `gpt-6.1-sol-codex-subscription`, `gpt-6-sol-codex-subscription`, `gpt-5.6-terra-codex-subscription`, `gpt-5.6-sol-codex-subscription`, `gpt-5.6-luna-codex-subscription`, `grok-4.6-grok-subscription`). `auto` defaults to DeepSeek Flash with native vision, following the server-configured Agent model. When that default is a GPT model, eligible accounts (including admins) can use the Codex subscription; an explicitly selected model or personal-plan route is preserved. Base GPT-5.6, GPT-6 and GPT-6.1 IDs select Azure API and base `grok-4.6` selects OpenRouter API; the suffixed IDs explicitly request the corresponding personal plan where authorized. This flag changes only the reasoning/tool-calling Agent LLM.

```bash
# Explicit lower-cost Agent LLM for a controlled comparison
npx makaron-cli chat --project auto --agent-model deepseek-v4-pro --json -b "make a 20s badminton video"
npx makaron-cli chat --project auto --agent-model gpt-6-luna-codex-subscription --json -b "reply with the active model"
npx makaron-cli chat --project auto --agent-model grok-4.6-grok-subscription --json -b "reply with the active model"
```

Returns immediately:
```json
{"runId": "xxx", "projectId": "...", "projectUrl": "https://www.makaron.app/projects/...", "status": "running"}
```

### Common workflows

| What you want | Example |
|--------------|---------|
| Edit an image | `npx makaron-cli chat --project <id> --image photo.jpg "remove the person in the background"` |
| Generate an image | `npx makaron-cli chat --project auto "generate a cinematic poster of a rainy Tokyo alley"` |
| Make a video from the current project | `npx makaron-cli chat --project <id> "make this into a 5 second cinematic video"` |
| Fix one moment in a video from a screenshot | `npx makaron-cli chat --project <id> --image screenshot.png "@4 this frame should be Paris; only fix this moment"` |
| Cut or assemble video | `npx makaron-cli chat --project <id> --video clip.mp4 "cut out the dead air and keep the best 20 seconds"` |
| Add music | `npx makaron-cli chat --project <id> "add calm piano background music"` |
| Beat-sync video from audio | `npx makaron-cli chat --project auto --audio beat.mp3 "use Seedance Mini at 480p to make a beat-synced video"` |
| Create motion design | `npx makaron-cli chat --project <id> "make an animated Instagram story with this image"` |

### Marketplace skills

External users can browse, install, and use marketplace skills with only `MAKARON_API_KEY`:

```bash
npx makaron-cli skills list
npx makaron-cli skills search "football"
npx makaron-cli skills search "足球"
npx makaron-cli skills show <marketplace-id-or-label>
npx makaron-cli skills install <marketplace-id-or-label>

# chat auto-installs matched marketplace skills before starting the run
npx makaron-cli chat --project auto --image selfie.jpg --skill <marketplace-id-or-label> -b "make this with the selected skill"
```

`--skill` accepts an installed skill name, a marketplace UUID, or a unique marketplace label. If a marketplace skill is matched, the CLI installs or reuses it and sends `[Active skill: <installed-skill-name>]` to Makaron Agent. Ordinary users do not need admin commands, and the CLI intentionally does not expose skill deletion.

### Built-in production skills

Pass the complete brief, source roles, budget and granted review authority to
`makaron chat` in natural language; the internal Agent selects a matching Skill.
Use `--skill <name>` when explicitly selecting an entry below.
Makaron's internal Agent reads the selected Skill and its dependencies and owns
the production/review workflow. Let that Skill own the detailed procedure.

<!-- makaron:workflow-directory:start -->
| Request | `--skill` entry |
| --- | --- |
| Ordinary image editing/generation, music or single-clip video | Omit `--skill` for automatic routing |
| Multi-part narrative with consistent characters/scenes | `long-video-director` |
| Faithfully recreate reference shot structure with replacement content | `video-edit`; request the replication profile in the brief |
| Explain a topic, product or process | `explainer-video` |
| Trailer, teaser, brand film or cinematic short | `cinematic-video` |
| Speech-led cuts, captions and B-roll | `talking-head` |
| Translate/dub/localize an existing video | `video-translate` |
| Package existing source footage for TikTok/Douyin | `tiktok-video` |
| Whole-take multi-angle re-shoot preserving the performance/timebase | `multi-angle-video` |
| Explicitly create progressive story images before video | `photo-to-video` |
<!-- makaron:workflow-directory:end -->

For a low-cost planning check, include: "Select the matching Skill and give a
short production plan; stop before generating any image, video or audio."
Planning still uses Agent inference. Detailed production remains internal.

When a name or scope is uncertain, use `makaron skills list --built-in`,
`makaron skills search "<request>" --built-in`, or
`makaron skills show <name> --built-in`; the live list is authoritative.
Built-in Skills need no marketplace installation. Supporting anchor/storyboard
Skills are internal dependencies rather than separate production entrypoints.
For invocation/status diagnostics, see [internal workflows](skills/makaron/references/internal-workflows.md).


### With additional images (existing project)

```bash
npx makaron-cli chat --project <id> --image ref1.jpg --image ref2.jpg -b "use these as style reference"
```

### Inspect existing timeline media

Before starting a follow-up run on an existing project, list the current timeline media so you know what assets are available and which `<<<media_N>>>` references to use:

```bash
npx makaron-cli project media <projectId> --json
```

This is project-scoped. `responses get <runId> --pick output` only returns artifacts from one run; `project media` returns the whole project timeline: original uploads, references, generated images, video snapshots, and editable compositions.

Typed external images and video ranges can be added without uploading the original media:

```bash
npx makaron-cli project media add <projectId> \
  --type image \
  --source-url "https://cdn.example.com/product.jpg" \
  --description "Hero product image"

npx makaron-cli project media add <projectId> \
  --type video \
  --source-url "https://cdn.example.com/source.mp4" \
  --start 12.5 --end 19 \
  --description "Racket frame molding"

# Batch form: a JSON array or {"clips": [...]}
npx makaron-cli project media add <projectId> --input media.json --json
```

Every item must declare `type` as `image` or `video`. Images contain
`source_url + type + description` and do not have a time range. Videos contain
`source_url + type + start + end + description`; their ranges remain
non-destructive metadata, and Remotion must trim the original URL to those exact
source bounds. The returned `<<<media_N>>>` is immediately usable by a later
Agent run.
Use `description` as the provider-neutral media-understanding field. Put any
already-known summary, editorial purpose, concrete scene evidence, confidence,
and limitations there. Makaron exposes the full description in Media List
context so the Agent can edit from it without repeating image/video analysis
unless a required detail is missing or uncertain.

For an agent-to-agent handoff, create the project, import the typed external media,
and start the Agent in one command:

```bash
npx makaron-cli chat --project auto \
  --media-manifest set-01.json \
  --json -b \
  "Make a 30-second 9:16 TikTok with English VO and burned-in captions"
```

The manifest is a JSON array or `{ "title": "...", "clips": [...] }`. Every
item declares `type`. Images omit `start` and `end`; videos require both values
in seconds. Array order is edit order. It is validated before project creation
and supports up to 20 media items for one Makaron task. Batch planning remains
the upstream orchestrator's responsibility: convert each plan into one manifest
and start one independent Makaron task.

The server inspects imported image bytes, including extensionless Scene URLs.
HEIC/HEIF images are converted to durable JPEGs before entering the Media List;
use the returned media URL for generation and rendering. Compatible image URLs
(including transparent PNGs) and video source ranges are preserved. Conversion
or storage failure rejects the image import instead of saving an unusable URL.

### Export editable Remotion compositions

Animated Remotion compositions are saved as editable timeline/code artifacts first. To materialize one into an MP4 that CLI, V, or another service can read, call the backend export worker:

```bash
npx makaron-cli materialize --project <projectId> --media <N> --pick url
npx makaron-cli materialize --project <projectId> --design-json composition.json --pick url
npx makaron-cli composition export --project <projectId> --media <N> --wait
npx makaron-cli composition export --project <projectId> --snapshot <snapshotId> --wait
npx makaron-cli composition status <jobId> --wait
```

`materialize` is the preferred high-level command for Remotion-to-MP4. It defaults to `--wait`, `--publish`, and the `source` profile, preserving the composition's dimensions when the MP4 is added back to the project timeline. Use `--no-publish` when you need only a file URL. Use `--profile fast_720p` only when a 720-short-side export is acceptable.

For a run that produced an animated composition, materialize before picking the video URL:

```bash
npx makaron-cli responses get <runId> --materialize --wait --pick first_video_url
npx makaron-cli responses get <runId> --export-compositions --wait --pick first_video_url
```

To turn a Makaron Remotion design JSON file directly into an MP4, use `--design-json`. The JSON must be a Makaron/Remotion composition payload, not a provider-video task response. Always pass the destination project because published exports and storage paths are project-scoped:

```bash
npx makaron-cli materialize --project <projectId> --design-json composition.json --pick url
cat composition.json | npx makaron-cli materialize --project <projectId> --design-json - --pick url
```

This JSON-to-MP4 path uses the same defaults as timeline materialize: `--wait`, `--publish`, and `source`. Add `--no-publish` when another agent needs the MP4 URL without adding a timeline video.

The completed export reports `duration_seconds`, `render_seconds`, and `realtime_ratio` so agents can compare video length against export time. Do not apply provider-video ETA rules to Remotion materialize; with a warm exporter it is often near video length to tens of seconds, while cold starts can be longer.

In production, run the exporter as a separate warm worker:

```bash
REMOTION_EXPORT_INLINE_AFTER=false npm run worker:remotion-export:check
REMOTION_EXPORT_INLINE_AFTER=false npm run worker:remotion-export
```

Keeping this worker warm avoids paying sandbox cold-start cost on every CLI or service call.

Lambda exports are admitted by a shared capacity-weighted queue. The default
`REMOTION_EXPORT_LAMBDA_CAPACITY=330` preserves the current per-video
`REMOTION_LAMBDA_FRAMES_PER_LAMBDA=20` chunking while leaving headroom under the
account concurrency quota. A 30-second 30fps video is estimated as 45 renderer
Lambdas plus one control slot, so seven such videos can render concurrently and
the rest remain queued. `REMOTION_EXPORT_CRON_LANES` controls how many queue
lanes the one-minute rescue cron keeps warm; it does not raise the capacity cap.

### With video input (MP4/MOV/WebM)

```bash
# Upload a video and ask the agent to edit it
npx makaron-cli chat --project auto --video clip.mp4 -b "put Iron Man armor on me in this video"

# Combine video + image references
npx makaron-cli chat --project <id> --video party.mp4 --image kid.jpg -b "make this kid appear in the party"

# Multiple videos (for composition / continuation)
npx makaron-cli chat --project <id> --video clip1.mp4 --video clip2.mp4 -b "splice these into one seamless video"
```

Video files are uploaded via signed URL. CLI local video uploads support `.mp4`, `.mov`, or `.webm`, max 500MB, max 900s (15 minutes) with 1s metadata tolerance, and <=1080p / 2,086,876 frame pixels. The CLI uploads files over 6MB directly to Storage in 6MB resumable chunks without loading the entire file into memory and rejects videos above those limits. Local `makaron analyze --video` uploads also support max 500MB; analysis provider limits still apply.
For a new presenter or product video, ask for picture, speech, lip sync and music together in one `chat` brief. Seedance 2.5 defaults to Eco. Native subtitles can be included; for precise or editable captions, Makaron keeps the native soundtrack and adds text through a lightweight composition, without a Studio production recipe or another voice generation. Review the completed MP4 for speech, caption spelling and synchronization.

The agent understands video content natively — it can analyze scenes, edit, extend, and compose videos. Seedance video-reference editing is still limited to ~15s provider references, so longer uploaded videos should be split/prepared by the agent before model submission; Kling 4.0 supports direct edit for a 3-30s source.
Use `chat --project <id|auto> --video ...` for any project/timeline video work. Direct `video create` is standalone and does not write timeline entries.

### With reference audio (MP3/WAV)

Attach a short song, beat, or voice recording when the video should follow audio pacing:

```bash
npx makaron-cli chat --project auto \
  --audio beat.mp3 \
  -b "use Seedance Mini at 480p to make a 15s beat-synced video"
```

`--audio` accepts repeatable local files or public URLs. Local MP3/WAV files must be 2-15s and <=15MB; reference audio currently works with Seedance video generation.

`chat` intentionally has no video model or resolution flags. State both in the chat message so the Agent selects a compatible provider and resolution together. Use `video create` only when you explicitly need direct provider controls.

### Fix one video moment from a screenshot

When a video is mostly good but one moment needs a local fix, attach a screenshot of the problem frame and describe the correction in normal language:

```bash
npx makaron-cli chat --project <id> \
  --image screenshot.png \
  "@4 this frame should be Paris, keep the same style and only fix this moment"
```

Makaron can locate the screenshot in the video, regenerate only the nearby segment, and then print a `Next steps` command when the new clip should be stitched back into the full MP4.

### Check status (single query)

```bash
npx makaron-cli responses get <runId> --json
```

### Advanced: stream incremental events

```bash
npx makaron-cli responses watch <runId> --jsonl
```

Outputs one JSON per line as artifacts appear:
```
{"event":"output.added","item":{"id":"out_1","type":"image","status":"completed","url":"https://..."}}
{"event":"output.added","item":{"id":"out_2","type":"video","status":"rendering","task_id":"xxx"}}
{"event":"output.updated","item":{"id":"out_2","type":"video","status":"completed","url":"https://..."}}
{"event":"done","status":"completed"}
```

### Extract specific results

```bash
npx makaron-cli responses get <runId> --pick first_image_url
npx makaron-cli responses get <runId> --pick image_urls        # all images (JSON array)
npx makaron-cli responses get <runId> --pick first_video_url
npx makaron-cli responses get <runId> --pick video_urls        # all videos
npx makaron-cli responses get <runId> --pick project_url
npx makaron-cli responses get <runId> --pick text              # agent's text reply
npx makaron-cli responses get <runId> --pick output            # full output array
npx makaron-cli responses get <runId> --pick status
npx makaron-cli responses get <runId> --pick credits_used      # net credits this run cost
npx makaron-cli responses get <runId> --pick usage             # per-tool credit breakdown
npx makaron-cli responses get <runId> --events --json          # timestamped raw tool/event evidence, including active runs
npx makaron-cli responses get <runId> --events --after 1000 --json # next page after the last returned event sequence
```

## Fallback: Direct tool calls (no project context)

Use these only when `chat` is unavailable or you need raw model access without project/conversation context.

### `edit` — One-shot image editing

```bash
# Edit an existing image
npx makaron-cli edit --image photo.jpg "add cinematic warm lighting"

# Text-to-image (no input)
npx makaron-cli edit "a cyberpunk cityscape at night"

# With model/reference
npx makaron-cli edit --image photo.jpg --ref style.jpg "match this style"

# Output to file
npx makaron-cli edit --image photo.jpg --out result.jpg "make it dramatic"

# Strict transparent PNG/WebP output through GPT Image 2.5 Flare (fails rather than returning opaque)
npx makaron-cli edit --image-model gpt-image-2.5-flare --background transparent --out sticker.png "a magenta star sticker"
```

Options: `--image`, `--image-model gemini|gemini-2.1|gemini-lite|qwen-spicy|openai|gpt-image-2.5-flare|gpt-image-2.5-sunburst|gpt-image-2.6-flare|gpt-image-2.6-sunburst|wan2.7-image|mj-v8.2`, `--ref <file>` (model-specific limit), `--aspect <ratio>`, `--background auto|opaque|transparent`, `--out <path>`. Nano Banana 2.1 (`gemini-2.1`) supports up to 14 total input images and `--image-resolution 1K|2K|4K` (default 1K); it uses OpenRouter and does not retry or switch models automatically. Qwen Spicy supports 0–3 input images; legacy `qwen` requests map to it. Pony and WAI are retired. Transparent output defaults to GPT Image 2.5 Flare; an explicitly selected GPT Image 2.5/2.6 variant is retained. Output is returned only when the provider supplies real alpha.

Midjourney V8.2 (`mj-v8.2`) accepts natural-language briefs and prepares the English prompt automatically. Fast returns up to 4 images, Draft up to 24 smaller drafts, and HD regenerates up to 4 higher-resolution images. Every returned image is saved; `--out scene.png` produces `scene-1.png`, `scene-2.png`, etc. A single result keeps the requested filename. Provider filtering can reduce the batch size.

```bash
npx makaron-cli edit --image-model mj-v8.2 --aspect 16:9 --out scene.png "星空下被水淹没的宫殿走廊"
npx makaron-cli edit --image-model mj-v8.2 --mj-quality hd --mj-stylize 400 --mj-chaos 10 --out hallway.png "A hallway flooded. A starry night sky with big puffy clouds above."
npx makaron-cli edit --image-model mj-v8.2 --style-ref 2231018166 --style-ref 4162055066 --out city.png "A massive city skyline peeking through a sea of clouds."
```

Midjourney-only options: `--mj-speed fast|draft`, `--mj-quality standard|hd`, repeatable `--style-ref <public-HTTPS-url|numeric-sref-code>`, `--mj-style-weight 0..1000`, `--mj-stylize 0..1000`, `--mj-chaos 0..100`, `--mj-seed 0..4294967295`, and `--mj-raw`. Draft cannot be combined with HD. This is image generation: do not use `--image` for precise edits, promise identity preservation, request transparent output or 4K, or treat HD as lossless upscaling. Public URL content references use `--ref`; local/base64 references are unsupported for this route. Failures and unknown paid outcomes are not automatically retried or switched to another model; keep the returned task ID. One provider batch is billed once, not once per candidate.

`wan2.7-image` uses Alibaba international for fast, approximately 1K generation and editing (default 6 credits/image). Failed or timed-out Wan requests are not automatically retried or switched to another model. Face identity can change. Example: `makaron edit --image portrait.jpg --image-model wan2.7-image --aspect 16:9 --out stadium.jpg "Place this woman in a baseball stadium, preserving her face."`

### `video` — Standalone video tools (no project timeline)

```bash
# 1. Write script from images
npx makaron-cli video script --image img1.jpg "cinematic story"

# 2. Analyze a video (standalone, no timeline write)
npx makaron-cli analyze --video input.mp4 "describe the key actions and pacing"

# 3a. Submit reference-to-video rendering (images must be public URLs from step 1 or uploaded)
npx makaron-cli video create --script "Shot 1 (5s): <<<image_1>>> ..." --image https://...jpg --duration 5 --video-model kling-4
npx makaron-cli video create --script "Shot 1 (5s): <<<image_1>>> slow cinematic push-in with native ambience" --image https://...jpg --duration 5 --video-model grok
npx makaron-cli video create --script "Keep both subjects recognizable as they enter the same studio" --image https://...jpg --image https://...webp --duration 5 --video-model grok --video-resolution 720p
npx makaron-cli video create --script "Shot 1 (15s): <<<image_1>>> and <<<image_2>>> build a neon one-person studio" --image https://...jpg --image https://...webp --duration 15 --video-model seedance-mini --video-resolution 480p --aspect 9:16

# 3b. Native SeeDance, Wan 3.0, MiniMax H3, or fal H3 Turbo text-to-video (no image required)
npx makaron-cli video create --script "Shot 1 (5s): A neon one-person studio wakes at dawn" --duration 5 --video-model seedance-fast --aspect 16:9
npx makaron-cli video create --script "Shot 1 (15s): A premium creative editor comes alive" --duration 15 --video-model minimax-h3 --aspect 16:9
npx makaron-cli video create --script "Shot 1 (5s): A tiny robot runs through a sunlit studio" --duration 5 --video-model minimax-h3-max
npx makaron-cli video create --script "Shot 1 (5s): <<<media_1>>> turns toward camera" --image https://...jpg --duration 5 --video-model minimax-h3-max --video-resolution 768p

# 3c. Edit a video from a local file or public URL
npx makaron-cli video create --script "make it funny" --video input.mp4 --duration 5 --video-model seedance-fast
npx makaron-cli video create --script "make it warmer and cinematic" --video https://example.com/input.mp4 --duration 5 --video-model seedance --video-resolution 1080p
npx makaron-cli video create --script "turn the light warm gold but preserve the action" --video input.mp4 --video-model grok --video-operation edit
npx makaron-cli video create --script "continue the camera move into the next beat" --video input.mp4 --video-model grok --video-operation extend --duration 4

# 4. Check status
npx makaron-cli video status <taskId>

# Rebuild only 2–5 seconds and publish the complete video into the project.
npx makaron-cli video retake --video input.mp4 --start 2 --end 5 --prompt "Make the umbrella red" --project <id> --model seedance-2.5 --wait --json
```

Video segment editing also works directly from natural-language chat, without a GUI selection:

```bash
npx makaron-cli chat --project <id> "把 @1 的 18–21 秒切成多机位，其余不变"
npx makaron-cli chat --project <id> "把 @1 的最后三秒改成夜景"
```

Chat resolves the source/range, inspects the footage, expands the edit instruction, and delivers the complete video. It asks only when the source or scope remains ambiguous. Precise cuts, subtitles, dubbing and extension also start from chat. Local editing accepts a 0.1–15s range in a source up to 120s; longer scopes use the appropriate whole-video workflow rather than silently shortening the request.

For project/timeline video editing, use:

```bash
npx makaron-cli chat --project <id|auto> --video input.mp4 -b "make it funny"
```

Kling 4.0: use `--video-model kling-4` for native text-to-video or image/video feature references, integer 3–30s at 720p (default) or 1080p. Up to 10 images and 5 videos; source videos must each be 3s or longer, total at most 30s, 720–2160px per side, 24–60fps and at most 200MB each. `--video-operation edit` requires exactly one source video and preserves its canvas/audio. Explicit keyframe I2V, extension and replacement-audio controls are not exposed. Retake defaults to `kling-4` at 720p, original audio only, source at least 3s, no final/middle frame control. `kling-4-flash` is unavailable: no verified independent callable API or price; never silently substitute the standard model.

Options for `video create`: `--script "..."`, `--script-file <path>`, `--image <url>` (repeatable, up to the selected model limit), `--video <file|url>` and `--audio <file|url>` (repeatable where supported), `--voice <xai-preset-id>` (repeatable, Grok only), `--duration <seconds>`, `--aspect 9:16|16:9|1:1`, `--video-model seedance-fast|seedance-mini|seedance|seedance-2.5|wan-3.0|wan-3.0-prime|kling-4|grok|google-omni|minimax-h3|minimax-h3-max|fal-h3-max|sync-lipsync-v3`, `--video-resolution auto|480p|720p|768p|1080p|2k|4k`. Default model is FAL H3 Max (`fal-h3-max`) at 768p (480p/1080p optional): native text-to-video or image/video/audio reference-to-video, integer 5-15s, up to 9 images + 3 videos + 3 audios (12 total). SeeDance accepts native text-to-video with no image and integer output duration 4-15s (default 5s); every Seedance image input is submitted through reference-to-video, including one image. `seedance-mini` supports 480p/720p and is best for cheaper drafts/multi-size tests. Wan 3.0 and Wan 3.0 Prime both expose 480p/720p/1080p/2K/4K; 2K/4K automatically use the matching FlashVSR endpoint. MiniMax H3 accepts native text-to-video, 4-15s output, public 768p/2k resolution, and up to 9 image, up to 3 video, and up to 3 audio feature references through Makaron Agent/chat; a single image keeps the `reference_image` role. `sync-lipsync-v3` requires exactly one video plus one MP3/WAV and preserves that replacement audio while aligning the mouth. H3 defaults to 768p; request 2k explicitly for maximum/final quality. Kling 4.0 supports integer 3-30s in one call. Grok generation uses `grok-imagine-video-1.5`: text-only generation supports 480p/720p/1080p, while any 1-7 image or preset voice input uses reference-to-video and is capped at 720p. Grok edit/extend uses `grok-imagine-video` internally under the same `grok` selector. Gemini Omni supports 3-10s fast image/video generation and editing with native generated audio; every image-only generation request uses `reference_to_video`, including a single image, with up to 6 images when no video reference is provided.

fal H3 Turbo: use `--video-model minimax-h3-max` for faster-than-real-time generation. It supports exactly 5/10/15 seconds at 480p/768p and defaults to native 768p, with no image for T2V or exactly one `--image` for I2V. It does not accept reference video/audio or multiple images.

Seedance 2.5: use `--video-model seedance-2.5` or `seedance-2.5-eco` for 4-30 second videos generated at 480p then automatically upscaled to 720p, 1080p (default), 2K or 4K. Use `seedance-2.5-native` explicitly for native output at 480p (default) or 720p. `--image` accepts local files or URLs (up to 30), while repeatable `--video` and `--audio` accept up to 10 each. Use `--video-operation generate|edit|extend`, `--extend-direction forward|backward`, `--output-format mp4|mov`, `--web-search`, `--generated-audio` / `--no-generated-audio`, and `--relaxed-content-filter`. Edit/extend require a video reference. Eco delivers MP4; MOV is native-only. The native Evolink route does not expose 4K output.

Wan 3.0: choose `--video-model wan-3.0` or the faster `--video-model wan-3.0-prime`. Both support 2-30 second generation, 480p/720p/1080p/2K/4K, and up to 10 images, 5 videos, and 5 audio references. Pass `--video-resolution 2k|4k` to use the matching FlashVSR/Pro endpoint automatically; Pro is not a separate model selector. Use generation mode with feature references; typed edit/extend and `--relaxed-content-filter` are not supported.

Video edit model behavior: `--video-model kling-4 --video --video-operation edit` uses Kling 4.0 direct edit and preserves source audio; `--video-model seedance-fast --video`, `--video-model seedance-mini --video`, or `--video-model seedance --video` uses the SeeDance video-reference path and requires target <=15s, <=50MB, width/height 300-6000px, aspect ratio 0.4-2.5, and frame pixels 409,600-2,086,876. `--video-model minimax-h3 --video` uses H3 feature/reference mode: up to 3 video references totaling <=15s, each <=50MB with width/height 256-5760px and aspect ratio 0.4-2.5. `--video-model google-omni --video` uses Gemini Omni direct video editing and accepts one reference video in Makaron. Output duration is clamped to 3-10s. `--video-model grok --video --video-operation edit` accepts one MP4 up to 8.7s, retains duration/aspect, and caps output at 720p. `--video-operation extend` accepts one 2-15s MP4 and adds 2-10s (default 6s); the returned result includes the original plus extension.

### `music` — Music generation

```bash
npx makaron-cli music create "gentle piano, warm strings, cinematic"
npx makaron-cli music create --vocals --style "lo-fi" "rainy day vibes"
npx makaron-cli music status <taskId>
```

Options: `--vocals` (include vocals), `--style "genre"`

## Response Schema

```typescript
type MakaronRunResponse = {
  id: string
  status: "in_progress" | "completed" | "failed" | "aborted"
  incomplete: boolean                // true = keep polling
  project_id: string
  project_url: string
  next_poll_after_ms?: number        // suggested poll interval
  output: MakaronOutput[]
  usage?: MakaronRunUsage            // credits this run cost; present once the agent has stopped
}

type MakaronRunUsage = {
  credits_charged: number            // sum of debits
  credits_refunded: number           // e.g. a failed video reservation
  credits_net: number                // what the run actually cost (1 credit = $0.01)
  input_tokens: number
  output_tokens: number
  entries: { tool_name: string; model: string | null; calls: number; credits: number }[]
  balance?: number                   // account balance after this run
}

type MakaronOutput =
  | { id: string; type: "text"; status: "completed"; content: string }
  | { id: string; type: "image"; status: "completed"; url: string; snapshot_id: string }
  | { id: string; type: "design"; status: "completed"; url: string; width: number; height: number; animated: boolean; duration?: number }
  | { id: string; type: "video"; status: "queued"|"rendering"|"completed"|"failed"; task_id: string; snapshot_id?: string; url?: string; elapsed_seconds?: number; width?: number; height?: number; error?: string; completion_actions?: CompletionAction[] }
  | { id: string; type: "music"; status: "queued"|"rendering"|"completed"|"failed"; task_id: string; url?: string; elapsed_seconds?: number }

type CompletionAction = {
  label: string
  prompt: string
  description?: string
  policy?: "confirm" | "auto"
}
```

## Polling Rules

1. Poll while `incomplete: true` or `status` is `"in_progress"`
2. Use `next_poll_after_ms` as interval (default 5000ms)
3. Stop when `status` is `"completed"`, `"failed"`, or `"aborted"`
4. Top-level `status: "completed"` means ALL artifacts are ready (including rendered videos)
5. If an async video fails, top-level `status` is `"failed"` and the failed video may include `completion_actions` for a safe retry or diagnosis. Agents can surface these as the next user-confirmed step.
6. `responses get --wait` reconciles pending video output against completed Project Media with the same `snapshot_id` or `task_id`. A lagging Run row therefore does not block delivery after the durable project video is ready.

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success (completed) or valid in-progress response |
| 1 | Failed, aborted, or HTTP error |
| 2 | Timeout (partial response still printed to stdout) |

## What Makaron Agent Can Do

| Task | Example prompt |
|------|---------------|
| Edit photo | "make it cinematic with warm tones" |
| Style transfer | "convert to oil painting style" |
| Add/remove elements | "add a cat on the table" / "remove background person" |
| Text-to-image | "generate a cyberpunk cityscape" |
| Video from image | "create a 5 second video of her walking" |
| Video with model | "use seedance model, make a 5s video" |
| Real MP4 edits | `--video clip.mp4 "trim this to the best 20 seconds and preserve audio"` |
| **Edit video** | **"put Iron Man armor on me in this video"** |
| **Compose videos** | **"combine @1 and @2 into one party video"** |
| **Extend video** | **"continue the story for 10 more seconds"** |
| Background music | "add calm piano music" |
| Motion design | "create an Instagram story with animated text" |
| Multi-step | "edit the photo then make a video from it" |

## Recommended Pattern: Service Flow (Feishu/OpenClaw/Group Chat)

When serving end-users in a chat environment (Feishu, Slack, Discord), use this proactive message pattern:

```bash
# 1. Immediately acknowledge the user
send_message "Got it! Working on it now..."

# 2. Create project + submit (one command)
RUN_ID=$(npx makaron-cli chat --project auto --image photo.jpg -b "make it cinematic and create a 5s video")

# 3. Send project link proactively
PROJECT_URL=$(npx makaron-cli responses get $RUN_ID --pick project_url)
send_message "Project created: $PROJECT_URL"

# 4. Wait for the final customer-ready result
RESULT=$(npx makaron-cli responses get $RUN_ID --wait --json)
IMAGE_URLS=$(echo "$RESULT" | jq -r '[.result.images[]?.imageUrl, .output[]? | select(.type == "image") | .url] | map(select(. != null)) | unique | .[]')
VIDEO_URLS=$(echo "$RESULT" | jq -r '[.result.videos[]?.videoUrl, .output[]? | select(.type == "video") | .url] | map(select(. != null)) | unique | .[]')

for URL in $IMAGE_URLS; do
  send_image "$URL"
done
for URL in $VIDEO_URLS; do
  send_video "$URL"
done
send_message "All done!"
```

**Key principles for service agents:**
- **Proactive, not silent**: Acknowledge immediately, send the project link early, then send the final customer-ready media when the run completes.
- **Media over links**: When possible, send images/videos as native media in the chat (download URL and upload as attachment), not just paste the URL.
- **Immediate acknowledgment**: Reply within 1 second of receiving user request. Don't make users wait for project creation.
- **Project link early**: Send the project URL right after creation so users can check anytime.
- **Use `get --wait --json` as the default service path**: reserve `watch --jsonl` for advanced streaming or debugging integrations that explicitly need incremental events.

## Important Notes

- One project = one conversation thread. All history is preserved.
- One active Agent Run at a time per project. A new message received while it is active is appended to that same Agent Run and processed at a durable work-unit boundary; it does not interrupt the execution or create a second owner for an in-progress Studio workflow.
- Multi-image: `create --image a.jpg --image b.jpg` or `chat --image ref.jpg`.
- Video timing depends on the selected model: fal H3 Turbo and fal H3 Max usually finish in tens of seconds; Max with video references may take around 1-2 minutes. Queue and saving time can vary; other providers may take 3-5 minutes; current Grok generation/edit probes are usually around 15-60 seconds; Gemini Omni is usually around 30-70 seconds plus Storage handoff. Remotion compositions should be converted with `materialize` / `responses get --materialize`, and timing should be read from `duration_seconds`, `render_seconds`, and `realtime_ratio`.
- Music takes ~60 seconds. Appears in output when done.
- Images are typically ready in 15-30 seconds.
- stdout is always machine-readable JSON/text. Human-friendly logs go to stderr.
- Always use `chat` as the primary interface — even for single image edits.
- `edit`/`video`/`music` are fallback tools for when `chat` is unavailable or you need raw model access without project context.
- The CLI checks npm for updates at most once per day and prints update notices to stderr. Set `MAKARON_DISABLE_UPDATE_CHECK=1` to disable it.

## Admin: Skill Marketplace Operations

Admin commands require an API key with admin privileges. Ask your admin to run `makaron admin set-admin <your-email>` to grant access.

### Add credits to a user

Use either the account email address or the Supabase user UUID. Credits must be a positive integer.

```bash
npx makaron-cli admin add-credits user@example.com 1000
npx makaron-cli admin add-credits <user-id> 1000 --json
```

### List all marketplace skills

```bash
npx makaron-cli admin skills
npx makaron-cli admin skills --json
```

The human-readable list includes assigned categories plus title/prompt locale completeness.

### Manage marketplace categories

```bash
npx makaron-cli admin skill-categories
npx makaron-cli admin skill-categories --json
npx makaron-cli admin skill-categories add '{"id":"portrait-effects","labels":{"en":"Portrait Effects","zh":"人像特效","zh-Hant":"人像特效","ja":"ポートレート効果"},"icon":"✨","sort_order":10}'
npx makaron-cli admin skill-categories update portrait-effects '{"icon":"📸"}'
npx makaron-cli admin skill-categories delete portrait-effects
```

Deleting a category is blocked while any marketplace skill still uses it.

### Upload assets to Storage

```bash
# Upload cover image (3:4 aspect ratio recommended)
npx makaron-cli admin upload cover.jpg marketplace/covers/skill-name.jpg

# Upload before photo
npx makaron-cli admin upload before.jpg marketplace/before/before-name.jpg

# Upload skill zip
npx makaron-cli admin upload skill-name.zip marketplace/skills/skill-name.zip
```

Storage paths follow this convention:
- Covers: `marketplace/covers/<skill-name>.jpg` (or `.mp4` for video covers)
- Before images: `marketplace/before/<name>.jpg`
- Skill zips: `marketplace/skills/<skill-name>.zip`

### Add a new skill to marketplace

```bash
npx makaron-cli admin skills add '{
  "labels": {"en": "English Name", "zh": "中文名", "zh-Hant": "繁體名稱", "ja": "日本語名"},
  "image": "https://sdyrtztrjgmmpnirswxt.supabase.co/storage/v1/object/public/images/marketplace/covers/skill-name.jpg",
  "prompts": {"en": "Default prompt", "zh": "默认提示词", "zh-Hant": "預設提示詞", "ja": "デフォルトプロンプト"},
  "categories": ["portrait-effects"],
  "skill_path": "https://sdyrtztrjgmmpnirswxt.supabase.co/storage/v1/object/public/images/marketplace/skills/skill-name.zip",
  "image_count": 2,
  "sort_order": 10,
  "is_active": true,
  "before_images": ["https://sdyrtztrjgmmpnirswxt.supabase.co/storage/v1/object/public/images/marketplace/before/before-name.jpg"]
}'
```

New skills require all four localized titles, all four localized default prompts, and at least one existing category. Partial `labels` or `prompts` updates are merged with existing locales, so updating one language does not erase the others.

### Update / delete a skill

```bash
npx makaron-cli admin skills update <id> '{"sort_order": 5, "is_active": false}'
npx makaron-cli admin skills delete <id>
```

### Download skill from share link

```bash
# From share code
npx makaron-cli admin fetch-skill 4c4cbd57

# From full URL
npx makaron-cli admin fetch-skill https://www.makaron.app/s/4c4cbd57

# → Creates ./skill-name/ directory with SKILL.md + assets/
```

### End-to-end skill launch workflow

0. **Get skill from share link** — `npx makaron-cli admin fetch-skill <code>`
1. **Read SKILL.md** — understand the skill's variables, prompt template, and output format
2. **Generate before photo** — use Makaron MCP `makaron_edit_image` to generate a plain selfie (no phone in frame, natural light)
3. **Generate cover photo** — use `makaron_edit_image` following the SKILL.md variables/style closely. Match gender pairing (female idol → male fan, male idol → female fan)
4. **Package zip** — `zip skill-name.zip SKILL.md` (video reference URLs go in SKILL.md metadata, not in the zip)
5. **Upload all assets**:
   ```bash
   npx makaron-cli admin upload cover.jpg marketplace/covers/skill-name.jpg
   npx makaron-cli admin upload before.jpg marketplace/before/skill-name-before.jpg
   npx makaron-cli admin upload skill-name.zip marketplace/skills/skill-name.zip
   ```
6. **Add to marketplace**:
   ```bash
   npx makaron-cli admin skills add '{"labels":{"en":"...","zh":"...","zh-Hant":"...","ja":"..."},"prompts":{"en":"...","zh":"...","zh-Hant":"...","ja":"..."},"categories":["portrait-effects"],"image":"<cover_url>","skill_path":"<zip_url>","before_images":["<before_url>"],"image_count":2,"sort_order":10,"is_active":true}'
   ```
7. **Verify** — visit https://www.makaron.app/home and confirm the skill appears, can be clicked, and works

### Cover image guidelines

- Target aspect ratio: **3:4** (marketplace cards use `object-fit: cover`)
- 16:9 images will be severely cropped — resize or stack two 16:9 images vertically
- Video covers (`.mp4`) are supported — auto-play in the card
- Before photo should match the person in the cover (hair, clothing, accessories)

FAL video models: **fal H3 Turbo** uses `minimax-h3-max` for single-start-frame I2V/T2V. **FAL H3 Max** uses the new selector `fal-h3-max`: native T2V or image/video/audio reference-to-video, default 768p, optional 480p/1080p, integer 5–15s; at most 9 images / 3 videos / 3 audios / 12 total. Reference video/audio each 2–15s and each modality totals at most 15s. Source-video modifications use generation with feature references, not typed edit/extend. Reference input tokens are billed in addition to output video; query current pricing.

GPT Image 2.6 Flare and Sunburst are explicit optional fal routes (`gpt-image-2.6-flare`, `gpt-image-2.6-sunburst`). This adapter returns one static PNG at low quality and low reasoning; GIF, SVG and markup overlays are not exposed. Auto stays on GPT Image 2.5 Flare. Exact active pricing rows are required before submission.

The legacy `openai` image-model parameter now resolves to GPT Image 2.5 Flare.

`chat --stream` follows the original durable run when its live connection ends before completion. It does not submit another generation; already printed reply text is not replayed.

Wan Retake (`wan-3.0` / `wan-3.0-prime`) rebuilds the selected interval using cropped video references and automatic assembly; it is reference-guided generation, with no native endpoint locks. Kling 4 remains the single default; choose alternatives explicitly.

Native Retake alternatives: `--model grok` uses xAI video editing (selection <=8.5s, source >=1s, at most 720p, no extra image references); `--model google-omni` uses native Google editing (selection <=10s, source >=3s); `--model minimax-h3` uses reference-guided rebuilding (source >=2s). These routes do not support exact final/middle/corrected-frame locks. MiniMax provider availability depends on its account balance; the October 23 real probe was rejected with HTTP 402 and produced no video.

Five matched native-edit cases found no universal quality/cost/speed winner: Grok was cheaper and faster but failed lettering and camera-change requests; Omni corrected lettering and kept book color better, but applied the product effect to the wrong object. Keep Kling as the API default, choose alternatives explicitly, and verify the actual requested object, action and joins. See `docs/research/retake-native-model-benchmark-2026-10-23.md` in the source repository for scope and evidence.
