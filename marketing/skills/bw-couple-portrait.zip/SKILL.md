---
name: bw-couple-portrait
description: >
  Generate high-contrast black and white romantic couple portraits
  in minimalist studio style — pure white background, intimate forehead-touching
  pose, fashion magazine editorial quality.
allowed-tools: generate_image analyze_image
metadata:
  makaron:
    icon: "🖤"
    color: "#1A1A1A"
    referenceImages:
      - assets/couple-reference.jpg
    tags: [portrait, couple, black-and-white, editorial, romantic]
    modelPreference: [gemini]
    faceProtection: strict
    defaultAspectRatio: "9:16"
---

# Black & White Couple Portrait (黑白双人肖像)

Generate high-fashion black and white romantic couple portraits with studio-quality lighting and minimalist composition.

## Visual Style

### Composition & Framing
- **Aspect ratio**: 9:16 vertical (portrait orientation)
- **Framing**: Close-up to mid-shot, subjects fill 70-85% of the frame
- **Background**: Pure white (#FFFFFF), completely clean with no distractions
- **Negative space**: Strategic use of white space above/around subjects for editorial feel

### Black & White Treatment
- **High contrast** monochrome — deep blacks in clothing and hair, bright whites in skin highlights and background
- **Rich tonal range** in midtones — skin texture, fabric weave, and hair detail should all be visible
- **No color cast** — pure black and white, no sepia or tinted tones
- **Film grain**: Subtle, fine grain for analog texture (not digital noise)

### Lighting
- **Soft directional top-light** as key light — creates gentle shadows under cheekbones and jawline
- **Fill from background** — the white backdrop acts as a natural fill, keeping shadow areas luminous
- **Hair light**: Subtle rim/edge light on hair to separate from background
- **Skin rendering**: Soft, luminous, with visible pores and natural texture — NOT airbrushed smooth

### Pose & Interaction
- **Primary pose**: "仰望与靠近" (looking up and leaning in) — one person slightly above, one below
- **Forehead touching / nose-to-nose**: The signature intimate gesture
- **Genuine smiles**: Both subjects show real, warm, radiant smiles — teeth visible, eyes crinkled
- **Hand placement**: One person's hand on the other's shoulder, neck, or chest — natural, gentle touch
- **Body language**: Relaxed trust, not stiff or posed — convey that the couple is lost in the moment

### Wardrobe & Styling
- **Female**: Minimal/sleeveless top or strapless (to emphasize clean shoulder lines), thick braid or elegant updo, silver hoop earrings, natural makeup
- **Male**: Black turtleneck sweater (高领毛衣) — clean, simple, elegant. Short textured hair
- **Contrast principle**: One subject in dark clothing, one with more exposed skin — creates strong visual separation

## Rules
- Always reference the provided couple portrait for pose, lighting, and mood consistency
- Maintain **fashion editorial quality** — this should look like it belongs in Vogue or Harper's Bazaar
- Expressions must be **authentic and warm** — never stiff, cold, or overly posed
- The emotional core is "pure, sweet, atmosphere-rich intimacy" (纯粹、甜蜜、充满氛围感)
- Background must remain pure white — no props, no set pieces, no environmental elements
- Both subjects' faces must be sharp and detailed — this is a portrait, faces are everything
- Preserve the "time stands still" quality — the moment feels suspended, private, tender
- When generating variations, keep the same intimate mood but vary: angle, which person is higher/lower, hand positions, head tilt directions
