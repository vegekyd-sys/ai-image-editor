---
name: idol-selfie
description: >
  Generate composite photos of you together with your idol in
  various scenes and poses — triple shots, flash snapshots,
  overhead selfies, photo booths and more.
allowed-tools: generate_image analyze_image
metadata:
  makaron:
    icon: "🤳"
    color: "#FF6B9D"
    tags: [fan, idol, selfie, composite, fun]
    tipsEnabled: true
    tipsCount: 4
    faceProtection: default
---

# Idol Selfie — AI Fan Meet Photo Generator

Generate realistic composite photos of you together with your
idol in various fun scenes and natural poses.

## Pose Library

### Category 1: Intimate Interaction
| Pose | Description |
|------|------------|
| Cheek Poke | One person poking the other's cheek with a finger, the other smiling |
| Shared Scarf | Both wrapped in the same scarf/blanket, cuddled close |
| Shoulder Lean | One resting head on the other's shoulder, or heads together |
| Arm Around | One arm casually over the other's shoulder |
| Mutual Gaze | Both turned sideways facing each other, not looking at camera |
| Chin Rest Gaze | One hand on chin gazing at the other, lazy relaxed vibe |

### Category 2: Selfie Poses
| Pose | Description |
|------|------------|
| Mirror Selfie | One holding phone in mirror, the other leaning close, phone visible |
| Overhead Selfie | High angle looking up at camera, heads exaggerated, tight framing |
| Half Heart | Each making half a heart with one hand, forming a complete heart together |
| V-sign Selfie | Both doing peace/V-sign close to their faces |

### Category 3: Props
| Pose | Description |
|------|------------|
| Shared Earphones | One earphone each, listening to the same song |
| Same Drink | Both hands on the same milk tea/coffee cup |
| Holding Polaroid Camera | One holding a Polaroid camera for a selfie |

### Category 4: Fun & Playful
| Pose | Description |
|------|------------|
| Back Hug | One hugging the other from behind, chin on shoulder |
| Princess Carry | One carrying the other, exaggerated romantic |
| Back to Back | Standing back to back, both looking cool at camera |
| Feeding Each Other | One holding food up to the other's mouth |
| Fake Encounter | Pretending not to know each other, sneaking side glances |

### Category 5: K-style Classic
| Pose | Description |
|------|------------|
| Finger Heart | Both making finger hearts together |
| Bouquet Photo | One holding a bouquet, the other leaning in close |
| Bunny Ears | Each making bunny ears behind the other's head |
| Pinky Promise | Linking pinky fingers together |
| Forehead Touch | Foreheads gently touching, eyes closed or looking at each other |

### Category 6: Daily Life
| Pose | Description |
|------|------------|
| Looking at Phone | Both looking down at the same phone screen |
| Walking Hand in Hand | Side view or back view, holding hands walking |
| Lying Down Selfie | Both lying side by side, camera above |
| Window Light | Both leaning by a window, natural light on faces |
| Couch Chill | Casually sitting together on a sofa, relaxed |

### Category 7: Fansite / Paparazzi
| Pose | Description |
|------|------------|
| Airport Arrival | Both getting out of a black car, holding hands, bodyguards around, one person shielding face from wind/sun |
| Red Carpet Walk | Walking side by side at an event, formal but intimate |
| Caught Off Guard | Candid moment spotted by fans, natural unposed reaction |

## Scene Templates

AI picks the best scenes by default (count configurable in Step 1, default 4), or user can choose specific ones.

| # | Scene | Default Poses | Style | Ratio |
|---|-------|--------------|-------|-------|
| 1 | Triple Shot · Warm | 3 frames: shoulder lean → mirror selfie → mutual gaze | Warm yellow film grain, heart stickers, cozy feel | 3:4 |
| 2 | Triple Shot · Dark | 3 frames: chin rest gaze → mirror selfie → forehead touch | Dark room, warm low-light, intimate night vibe | 3:4 |
| 3 | Flash Snapshot | Cheek poke or feeding each other | Dark room, camera flash spread across photo, slight motion blur, candid accidental feel | 16:9 |
| 4 | Overhead Selfie | Overhead selfie, tight and close | iPhone front camera, J/K-visual style, white background, exaggerated head proportions | 3:4 |
| 5 | Cafe Date | Shared earphones or same drink | Warm cafe lighting, Japanese fresh aesthetic | 4:3 |
| 6 | Street Snap | Arm around, walking together | Candid street photography, natural daylight | 3:4 |
| 7 | Polaroid | Half heart or forehead touch | Polaroid white border, handwritten date, soft tones | 1:1 |
| 8 | Fan Meeting | V-sign or arm around | Official event backdrop, professional lighting | 4:3 |
| 9 | Photo Booth Strip | 4 frames: smile → funny face → half heart → V-sign | Classic photo booth, colorful borders | 2:5 |
| 10 | Mirror Selfie | Mirror selfie, one holding phone | Real-life feel, phone visible in reflection | 3:4 |
| 11 | Airport Fansite | Holding hands, walking together | Fansite master telephoto shot, bodyguards in black, dark moody tones, sunlight on hair, medium grain, slight camera shake, shot from distance | 3:4 |

## Workflow

### Step 1: Collect Input

**Required:**
1. User's photo — 1-5 photos of the user (more photos = better face accuracy)
   - Best practice: include front-facing, slight side angle, different expressions
   - High quality, well-lit, face clearly visible and unobstructed
2. Idol's photo — 1-3 photos of the idol

**Optional:**
3. Scene count — how many scenes to generate (default: 4, range: 1-8)
4. Scene preference — pick specific scenes by number/name, or "auto" (default: auto)
   - If specific scenes are listed, scene count is inferred from the list length
5. Pose preference — pick from pose library or "auto"
6. Style — realistic / dreamy / cute cartoon (default: realistic)
7. Background preference — user can specify custom background (e.g. "white curtains", "cherry blossoms")

### Step 2: Analyze Photos

Call `analyze_image` on both sets to understand:
- Face positions, angles, and lighting direction
- Best photo pair combinations (matching angle/lighting)
- Outfit styles for scene matching

### Step 3: Generate Composite Photos — Batch Two-Pass Method

To maximize face fidelity for BOTH people, use a **two-pass generation** approach. This avoids forcing a single creative call to handle two faces at once, which causes distortion — especially for the user's face (an unknown face to the AI).

#### 3a: Select Scenes

Determine which scenes to generate based on user input:

**If user specified scenes:** Use exactly those scenes, in the order given.

**If "auto" (default):** Select {scene_count} scenes (default 4) from the 11 available, optimizing for:

1. **Diversity** — spread across different scene types:
   - Pick at most 1 triple-shot scene (scene 1 or 2, not both)
   - Pick at most 1-2 multi-frame scenes (triple-shot or photo booth)
   - Mix intimate, selfie, fun, and environment scenes
2. **Photo match** — prefer scenes whose lighting/angle matches the analyzed photos:
   - Dark/moody photos → Flash Snapshot, Triple Shot Dark, Airport Fansite
   - Bright/casual photos → Cafe Date, Street Snap, Overhead Selfie
   - Dressed up/formal photos → Fan Meeting, Polaroid
3. **Popular first** — when tied, prefer higher engagement scenes: Flash Snapshot, Overhead Selfie, Polaroid, Mirror Selfie

**Generation plan** — before generating, show the plan to the user:

| # | Scene | Poses | Ratio | API Calls |
|---|-------|-------|-------|-----------|
| 1 | {scene_1} | {poses} | {ratio} | 2 (Pass 1 + Pass 2) |
| 2 | {scene_2} | {poses} | {ratio} | 2 |
| ... | ... | ... | ... | ... |
| **Total** | | | | **{N × 2} calls** |

#### 3b: Generate — Loop Over Selected Scenes

Execute the two-pass method for **each scene** in the plan, sequentially.

**For scene {i} of {total} (i = 1, 2, ..., N):**

> Output: `"⏳ Generating scene {i}/{N}: {scene_name}..."`

##### Pass 1: Generate idol-only scene

Create the scene with ONLY the idol. This is a single-person generation, so the idol's face stays highly accurate.

- image: **idol's** best-fit photo
- referenceImages: [idol's other photos if available]
- skill: **creative**
- aspectRatio: per scene table
- useOriginalAsReference: true
- editPrompt: scene description + pose (idol's part only) + style keywords + "Generate a photo of ONE person in this scene. {pose_description_for_idol}. Leave natural space beside/near the person where a second person will be composited later — do NOT crop too tight. {style_keywords}. CRITICAL: the person's face must be strictly faithful to the original photo — preserve exact eye shape, nose, jawline, skin tone, all facial features."

**For scenes where the idol's position matters:**
- Shoulder lean / arm around → idol on one side, empty space on the other
- Mirror selfie → idol holding phone, space next to them
- Back hug → idol facing camera, space behind them
- Walking scenes → idol walking, space beside them

#### Pass 2: Insert user into the scene

Take the Pass 1 result and composite the user into it. Use `enhance` (NOT `creative`) to minimize transformation — the scene is already built, only the user needs to be added.

- image: **Pass 1 result** (the idol-in-scene image)
- referenceImages: [**ALL of user's photos**, up to 5] — pass every user photo for maximum face data
- skill: **enhance**
- aspectRatio: same as Pass 1
- useOriginalAsReference: true
- editPrompt: "Add a second person (from the reference images) into this photo. {pose_description_for_user}. The second person should be naturally integrated into the scene with matching lighting, perspective, and scale. CRITICAL — FACE LIKENESS: The added person's face must be EXACTLY like their reference photos — preserve exact eye shape, nose shape, jawline, skin tone, eyebrow shape, lip shape, and facial proportions. This person is NOT a public figure — the AI has no prior knowledge of their face and must rely ENTIRELY on the reference images. Do NOT generalize, beautify, average, or alter any facial features. A friend must instantly recognize this person. Also preserve the existing person (idol) in the scene — do NOT change their face or appearance."

#### Scene-Specific Two-Pass Prompts

**Triple shot scenes (3 frames):**

Pass 1: "Create a vertical image with 3 photo frames stacked. Each frame shows ONE person (the idol) in the same setting with different poses: Frame 1: {idol_pose_1}. Frame 2: {idol_pose_2}. Frame 3: {idol_pose_3}. {style_description}. Leave space beside the person in each frame for a second person to be added later. The person's face must be identical across all 3 frames."

Pass 2: "Add a second person (from reference images) into each of the 3 frames, naturally beside the existing person. Frame 1: {user_pose_1}. Frame 2: {user_pose_2}. Frame 3: {user_pose_3}. Match lighting and scale in each frame. CRITICAL: the added person's face must be strictly faithful to their reference photos across ALL 3 frames — same eye shape, nose, jawline, skin tone. Do NOT alter the existing person."

**Photo booth strip (4 frames):**

Pass 1: "Create a photo booth strip with 4 frames showing ONE person with different expressions/poses: Frame 1: {pose_1}. Frame 2: {pose_2}. Frame 3: {pose_3}. Frame 4: {pose_4}. Classic photo booth style with colorful borders. Leave space for a second person beside them in each frame."

Pass 2: "Add a second person (from reference images) into each of the 4 frames beside the existing person. Frame 1: {user_pose_1}. Frame 2: {user_pose_2}. Frame 3: {user_pose_3}. Frame 4: {user_pose_4}. CRITICAL: the added person must look exactly like their reference photos in all 4 frames. Preserve all facial features exactly. Do NOT alter the existing person."

**Flash snapshot:**

Pass 1: "Create a photo of ONE person in a dark room with camera flash. The flash illumination spreads across the entire photo. {idol_pose}. Slight motion blur for casual accidental feel. Leave natural space for a second person nearby."

Pass 2: "Add a second person (from reference images) into this flash snapshot photo. {user_pose}. Match the flash lighting and slight motion blur. CRITICAL: despite the flash effect, the added person's face must be clearly recognizable and exactly match their reference photos. Do NOT alter the existing person."

**Overhead selfie:**

Pass 1: "Create a high-angle overhead selfie of ONE person looking up at camera. Head proportions slightly exaggerated due to the angle. iPhone front camera feel. {background}. J/K-visual selfie style. Leave space beside them for a second person."

Pass 2: "Add a second person (from reference images) looking up at the camera beside the existing person. Tight framing, close together. Match the overhead angle and lighting. CRITICAL: the added person's face must match their reference photos exactly — same eye shape, nose, jawline, lip shape, skin tone. Do NOT alter the existing person."

**Airport fansite:**

Pass 1: "Create a fansite master-style airport photo. ONE person getting out of a black car, walking. Surrounded by bodyguards in all-black outfits and sunglasses. Subject in dark clothes, fair skin, wind blowing through hair. Sunlight hitting hair from above. Dark moody tones, slightly underexposed. Telephoto lens compression, medium film grain, slight camera shake. Leave space beside the person for a companion."

Pass 2: "Add a second person (from reference images) walking beside the existing person, holding hands. Both surrounded by bodyguards. The added person should match the dark moody tone, telephoto compression, and grain of the existing photo. CRITICAL: despite the distance and grain, the added person's face must be clearly recognizable and exactly match their reference photos. Do NOT alter the existing person."

> Output: `"✅ Scene {i}/{N} complete: {scene_name}"`

**Repeat for next scene until all N scenes are done. Then proceed to Step 4.**

### Step 4: Review and Iterate

After all scenes are generated, present results in a summary table:

| # | Scene | Result | Face Check |
|---|-------|--------|------------|
| 1 | {scene_name} | [image] | Pass / Needs redo |
| 2 | {scene_name} | [image] | Pass / Needs redo |
| ... | ... | ... | ... |

Then ask the user:
1. **Keep all** — save and finish
2. **Redo specific scenes** — specify which scene numbers to regenerate (with optional different pose/background)
3. **Add more scenes** — generate additional scenes beyond the original batch
4. **Swap a scene** — replace one scene with a different template
5. If face/likeness is off on any scene, regenerate that scene's Pass 2 (or both passes) with reinforced face instructions

### Step 5: Save Results (optional)

Ask user:
- Save all photos locally?
- Target directory (suggest `idol-selfie-output/`)

## Rules

### Face Likeness (TOP PRIORITY)
- Both faces must be **strictly faithful** to their original photos — preserve exact eye shape, nose shape, jawline, skin tone, eyebrow shape, lip shape, and facial proportions
- A fan must be able to instantly recognize both people without hesitation
- Do NOT generalize, beautify, average, or blend facial features — each person must look like themselves, not a generic attractive face
- Do NOT swap faces — each person keeps their own face
- After each generation, compare the result against the original photos. If EITHER face looks noticeably different from the original (different eyes, nose, jawline, or overall vibe), **discard and regenerate** with reinforced face-likeness instructions
- useOriginalAsReference: true for ALL calls (this is critical for face preservation)
- **Two-pass method:** Pass 1 generates idol-only scene with `creative` skill; Pass 2 inserts user via `enhance` skill. This isolates each face's generation and minimizes distortion — especially for the user's unknown face
- Pass ALL user photos (up to 5) in referenceImages during Pass 2 for maximum face data
- faceProtection: default (enabled in metadata)

### Scene & Composition
- Match lighting direction between both people for realism
- **Two-pass method:** Pass 1 builds the scene with idol only (creative skill), Pass 2 inserts user (enhance skill). This ensures each face is handled independently with minimal distortion
- Pass 1: idol photo as `image`, generate single-person scene with space for user
- Pass 2: Pass 1 result as `image`, all user photos in `referenceImages`, use `enhance` skill
- Respect the idol's image — no inappropriate or disrespectful scenes
- If user provides multiple photos, pick the best angle/lighting match for each scene
- For triple shot and photo booth: all frames must show the SAME two people with consistent faces, only poses change

### Batch Execution
- Default batch size is 4 scenes; respect user's scene_count parameter (range 1-8)
- Generate scenes sequentially — complete Pass 1 + Pass 2 for scene N before starting scene N+1
- Show progress between scenes so the user knows generation is ongoing
- If any single scene fails (e.g. face distortion detected), note it and continue with remaining scenes — do not abort the entire batch
- Present ALL results together at the end in a summary table, not one at a time
- For auto-selection, never pick two scenes that are visually too similar (e.g. both Triple Shot variants, or both Cafe Date and Street Snap)
