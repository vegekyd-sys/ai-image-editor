---
name: idol-building
description: >
  Generate idol fan support poster designs and composite them onto
  realistic building scenes — LED screens, subway walls, building facades,
  elevator doors, mall atriums and more.
  Two-step workflow: design poster first, then scene mockup.
allowed-tools: generate_image analyze_image
metadata:
  makaron:
    icon: "🏙️"
    color: "#6C5CE7"
    tags: [fan, idol, building, LED, support, banner]
    tipsEnabled: true
    tipsCount: 4
    faceProtection: default
---

# Idol Building — Fan Support Scene Generator

Generate realistic fan support scenes: idol photos displayed on
buildings, subway walls, elevator doors, mall atriums, street poles.
Two-step workflow: first design the poster, then composite onto the scene.
Each output uses a different photo + style for visual variety.

## Design Styles

Analyze the photo mood, outfit, color palette, and concept, then pick the most fitting style. Each style below is a design direction — adapt color palette to match the idol's outfit/theme color.

| Style | editPrompt Keywords |
|-------|-------------------|
| Soft Dreamy | "pastel gradient (pink-lavender or peach-cream), soft glow bloom lighting, translucent layered elements, pearl and ribbon accents, rounded sans-serif or calligraphy text, airy generous spacing, ethereal fairy-tale atmosphere" |
| Editorial Luxe | "high-fashion magazine layout, bold contrast between large serif title and fine sans-serif details, asymmetric grid, one dominant accent color + black/white, metallic foil text (gold or silver), generous negative space, Vogue/Harper's Bazaar editorial sophistication" |
| Scrapbook Collage | "scattered multi-photo layout in mixed frames (circle, polaroid, stamp-edge, torn-paper), washi tape and pin accents, handwritten notes, layered paper textures, warm off-white background, playful asymmetry, journal/zine aesthetic" |
| Bold Graphic | "flat bold color blocks, LARGE 3D outlined trilingual typography as dominant visual element, geometric shapes (circles, triangles, arrows), high-saturation complementary color pairs, thick outlines, Memphis/pop-art energy, each poster uses a DIFFERENT primary color" |
| Noir & Gold | "deep black or midnight navy background, gold foil / rose gold metallic accents, elegant high-contrast typography, thin ornamental line frames, subtle light particles, cinematic luxury, jewelry-ad sophistication" |
| Neon Glow | "dark urban background, vivid neon-colored glowing text and line art, color spill and light bloom on surroundings, electric blue/pink/green palette, futuristic nightlife energy, sharp geometric accents" |
| Holographic Glass | "iridescent rainbow gradient shifts, frosted glass morphism panels, chrome liquid-metal text, prismatic light refraction effects, translucent overlapping layers, futuristic premium feel" |
| Art Nouveau | "flowing organic curved borders inspired by Alphonse Mucha, botanical floral frames wrapping the person, ornamental arch composition, muted gold/sage/rose palette, elegant serif typography, stained-glass decorative patterns" |
| Y2K Cyber | "chrome bubble text, pixel art icons, rainbow gradient mesh backgrounds, halftone dot overlays, retro computer UI frames, nostalgic early-2000s web aesthetic, sticker-bomb layering, metallic shine" |
| Cosmic | "deep galaxy gradient (indigo to violet), constellation line art connecting stars, crescent moon motifs, silver/platinum metallic text with outer glow, cosmic dust particles, astronomical chart decorative elements" |
| Film Grain | "analog photography warmth, visible film grain texture, golden-hour light leak overlays, desaturated muted tones, handwritten margin notes, sprocket hole borders, Kodak/Fuji film stock feel" |
| Ink & Wash | "East Asian ink wash painting aesthetic, watercolor bleeding edges, brush-stroke calligraphy text, bamboo/plum blossom/cloud motifs, rice paper texture, balance of painted areas and raw white space, zen elegance" |
| Swiss Minimal | "strict grid layout, single accent color + white, bold Helvetica/sans-serif typography at extreme scale, minimal geometric marks (plus signs, dots, thin rules), maximum whitespace, photos placed at precise angles, information hierarchy through size contrast alone" |
| Retro Print | "risograph/screen-print texture with slight color misregistration, limited 2-3 color palette (e.g. coral + teal, or mustard + indigo), paper grain texture, overprint color mixing effects, vintage gig poster energy" |
| Baroque Opulence | "rich jewel tones (burgundy, emerald, sapphire), ornate gilded frame borders, damask/brocade texture backgrounds, classical serif typography, chandelier/crown/cameo decorative motifs, European palace grandeur" |
| Kawaii Pastel | "soft pastel color palette (baby pink, mint, lilac, lemon), plaid or polka dot pattern backgrounds, cute illustrated mascots and doodles, lace trim borders, speech bubbles, star/heart/bow motifs, rounded bubbly outlined text, sweet birthday-cafe party atmosphere" |

**Auto-selection — match photo mood to style:**
- Soft/dreamy/bright photo → Soft Dreamy, Kawaii Pastel, Art Nouveau, Film Grain
- Elegant/formal/dark outfit → Editorial Luxe, Noir & Gold, Baroque Opulence
- Cool/edgy concept → Neon Glow, Holographic Glass, Cosmic
- Colorful/energetic → Bold Graphic, Y2K Cyber, Retro Print
- Artistic/vintage → Film Grain, Ink & Wash, Art Nouveau
- Clean/minimal background → Swiss Minimal
- 3+ photos available → Scrapbook Collage
- Batch series (套图) → Bold Graphic (每张不同配色)
- First poster color: derive from idol's extracted outfit/theme color, NOT defaulting to pink
- Do NOT always default to the same 2-3 styles — explore the full range based on actual photos

## Text Templates

| Theme | Main Text | Sub Text | Decoration |
|-------|----------|----------|------------|
| Birthday | "HAPPY {NAME} DAY" | "{MM}.{DD}", "HBD", birthday blessing in {idol_lang} | Cake, balloons, crown, confetti |
| Anniversary | "{NAME} {N}TH ANNIVERSARY" | "{debut_date}", "Thank you for {N} years" | Stars, timeline, trophy |
| Concert | "{TOUR/ALBUM NAME}" | "IN {CITY}", concert cheer in {idol_lang} | Music notes, stage lights, microphone |
| TV/Film | "{SHOW NAME}" | "Starring {NAME}" | Clapperboard, film strip, spotlight |
| General | "{NAME}" / "ALL FOR {NAME}" | Fan club name, slogan | Hearts, lightsticks, fandom color |

**Language rules:**
- Idol name in English/Romanized (large hero text)
- Blessing in idol's language (Korean/Japanese/Chinese)
- Fan club credit in Chinese at bottom
- User-provided text overrides auto-generated text

## Scene Library (13 Scenes)

### A. Building Exterior

| # | Scene | Description | Poster Ratio | Environment Keywords |
|---|-------|------------|-------------|---------------------|
| 1 | Commercial Building Facade | Giant banner hung on building exterior wall, {locale_adj} street style | 3:4 | City street, daytime, looking up, power lines, street trees, shop signs |
| 2 | Skyscraper LED Wall | Full-face LED display on glass curtain wall skyscraper | 9:16 | Night, city skyline, ground level looking up, glass reflections |
| 3 | Times Square LED Screen | LED screen at busy intersection, Times Square / Shibuya style | 3:4 | Night, neon lights, taxis, pedestrians, multiple surrounding ad screens |

### B. Transit / Transportation

| # | Scene | Description | Poster Ratio | Environment Keywords |
|---|-------|------------|-------------|---------------------|
| 4 | Subway Wide Banner | Ultra-wide banner on subway corridor wall | 16:9 | Dark walls, fluorescent lights, tile floor, corridor depth, commuters |
| 5 | Subway Lightbox | Backlit lightbox ad on subway platform | 3:4 | Platform edge, train tracks, glowing lightbox, waiting passengers |
| 6 | Bus Stop Shelter | Lightbox poster in glass bus stop shelter | 3:4 | Glass shelter frame, bench, wet road reflections, night, car light trails |

### C. Mall Indoor

| # | Scene | Description | Poster Ratio | Environment Keywords |
|---|-------|------------|-------------|---------------------|
| 7 | Elevator Door Stickers | Full-cover stickers on paired mall elevator doors, arched frames with LED strips | 9:16 | Elevator doors, arched frame, LED strip lights, marble walls, floor indicator |
| 8 | Mall Display Board | Large freestanding display board on mall floor | 16:9 | Mall floor tiles, indoor lighting, surrounding shops, wayfinding signs, shoppers |
| 9 | Mall Hanging Banner | Extra-tall vertical banner hanging from upper atrium level, multi-photo stacked vertically | 9:16 | Atrium glass railings, multiple floors, skylight ceiling, opposite shops visible |
| 10 | Mall Atrium Full Setup | Ultimate fan support scene: giant hanging banners + multi-level flags + ground stage/flower arch + life-size standees | 3:4 | Atrium void, multiple visible floors, skylight, unified {theme_color} decoration, flower arrangements |

### D. Other Outdoor

| # | Scene | Description | Poster Ratio | Environment Keywords |
|---|-------|------------|-------------|---------------------|
| 11 | Street Lamp Flags | Paired vertical banner flags on street lamp pole, each side different design/photo | 3:4 | Lamp pole, city street, cars, bicycles, buildings background, daytime |
| 12 | Airport Arrival Hall | Series of lightbox ads in airport arrival corridor | 16:9 | Terminal walkway, moving walkway, flight info screens, travelers with luggage |
| 13 | Rooftop Billboard | Classic rooftop outdoor billboard with highway foreground | 16:9 | Billboard steel frame, dusk sky gradient, highway light trails |

## Workflow

### Step 1: Collect Input

Images attached in the user's message ARE the input photos — use them directly, do NOT ask the user to upload again.

**Required:** 1. Photos (1-7) — from user's attached images, 2. Name
**Optional:** Theme, date, fan club name, custom text, style, scene preference, campaign country/city
If name is not provided, infer from context or ask once.

**Locale resolution** (for scene environment + text language):
1. User-specified country/city → use directly
2. Infer from idol nationality: Korean → Seoul, Japanese → Tokyo, Chinese → Shanghai, Taiwanese → Taipei, Western → New York
3. Default: generic modern city (no specific country markers)

Set `{locale_city}`, `{locale_adj}` (e.g. "Seoul", "Korean"), `{idol_lang}` (e.g. Korean/Japanese/Chinese/English).

### Step 2: Analyze Photos

Call `analyze_image` on all photos to understand:
- Composition: close-up, half-body, or full-body
- Outfit colors → extract theme color for poster design
- Photo mood/vibe → inform style selection

Evaluate best layout for each photo:
- Close-up → large hero image, occupying 60%+ of poster
- Half-body → side layout or medium placement
- Full-body / multi-pose → collage layout
- Multiple photos → auto-recommend K-style Collage

### Step 3: Design Poster (Step A)

Based on style + theme + photo analysis, generate the poster design.

Call `generate_image` with:
- image: the allocated photo
- referenceImages: additional photos (for collage layouts)
- editPrompt: poster design instructions (style keywords + text content + layout)
- skill: creative
- aspectRatio: per scene table
- useOriginalAsReference: true

**MANDATORY in every editPrompt:** append "CRITICAL: The person's photo on the poster must be EXACTLY as in the original — same face, same pose, same outfit. Do NOT modify the person. The poster design elements (text, decorations, borders) go around the person's photo."

**Poster editPrompt template:**
"Design a fan support poster for {name}. {style_keywords}. Layout: the person's photo as the dominant visual element. Text: '{name}' in large decorative font as hero text, '{theme_text}' as secondary text, '{fan_club}' as small credit at bottom. Background: {theme_color} gradient (not flat solid). Decorations: {decoration_keywords}. {text_language_instructions}. Print-quality design, bold and readable at building scale."

For **multi-photo collage** (K-style Collage with 3+ photos):
"Design a fan support collage poster for {name}. Feature multiple photos in a creative scattered layout — one large hero photo + smaller inset photos in varied frames (circle, polaroid, stamp-edge). {style_keywords}. '{name}' in HUGE decorative text. '{theme_text}' woven between photos. Journal sticker elements, washi tape accents. Background: warm cream with {theme_color} accents."

### Step 4: Composite to Scene (Step B)

Take the poster design from Step 3 and composite it onto the building scene.

Call `generate_image` with:
- image: the poster design from Step 3
- editPrompt: scene environment description + "the uploaded image is displayed as a large advertisement on {scene_description}"
- skill: creative
- aspectRatio: per scene table
- useOriginalAsReference: true

**Scene editPrompt templates:**

**Building Facade:**
"Create a photorealistic {locale_adj} urban street scene in {locale_city}. The uploaded image is displayed as a giant fan support banner hung on a commercial building exterior wall. Viewed from street level looking up. Environment: daytime, power lines, street trees, shop signs, pedestrians, realistic {locale_adj} cityscape. The banner looks professionally printed and physically mounted on the building. Correct perspective distortion for the viewing angle."

**Skyscraper LED Wall:**
"Create a photorealistic nighttime cityscape. The uploaded image is displayed as a full-face LED advertisement on a glass curtain wall skyscraper. The LED display is the brightest element, casting colored light on surrounding buildings. City skyline, ground level perspective looking up, glass reflections on nearby buildings. The display looks like a real LED screen with slight pixel texture."

**Times Square LED Screen:**
"Create a photorealistic nighttime busy intersection. The uploaded image is displayed on a giant LED screen at a Times Square / Shibuya crossing style location. Neon lights, taxis, pedestrians, multiple surrounding ad screens. The LED screen casts colored glow on wet pavement. Dramatic night photography feel."

**Subway Wide Banner:**
"Create a photorealistic subway station corridor. The uploaded image is displayed as a wide horizontal fan support banner covering the corridor wall. Dark corridor walls, fluorescent ceiling lights, tile floor, passing commuters. The banner is professionally installed, flush against the wall. Correct perspective for corridor depth."

**Subway Lightbox:**
"Create a photorealistic subway platform. The uploaded image is displayed in a backlit lightbox advertisement on the platform wall. Platform edge, train tracks visible, the lightbox glows with even illumination. Waiting passengers nearby. The lightbox has a thin aluminum frame."

**Bus Stop Shelter:**
"Create a photorealistic night street scene. The uploaded image is displayed as a lightbox poster inside a glass bus stop shelter. Glass shelter frame, bench, wet road surface reflecting the lightbox glow. Car headlight trails in background. Night atmosphere with ambient city lighting."

**Elevator Door Stickers:**
"Create a photorealistic photo of mall elevator doors. Two elevator doors side by side, both fully covered with the uploaded image as fan support poster stickers. Arched door frames with LED strip lighting. Marble wall surroundings, floor indicator between doors. Indoor mall lighting. The stickers are applied smoothly and precisely."

**Mall Display Board:**
"Create a photorealistic shopping mall interior. The uploaded image is displayed on a large freestanding display board on the mall floor. The board is horizontal format, slightly angled. Mall floor tiles, indoor lighting, surrounding shop fronts, wayfinding signs, shoppers walking past. The board looks like a real installed display."

**Mall Hanging Banner:**
"Create a photorealistic shopping mall atrium. The uploaded image is displayed on an extra-tall vertical banner hanging from the upper level. Atrium glass railings visible on multiple floors, skylight ceiling above, opposite shops visible. The banner hangs with slight fabric drape. Natural daylight from skylight illuminates the banner."

**Mall Atrium Full Setup:**
"Create a photorealistic multi-story shopping mall atrium decorated for a fan support event. The uploaded image appears on a giant hanging banner dropping from the top floor. Multiple smaller banners with the same theme on each level. Ground floor: themed stage area with flower arrangements and life-size idol standees. Unified {theme_color} decoration throughout. Natural skylight, shoppers on multiple floors. Maximum visual impact."

**Street Lamp Flags:**
"Create a photorealistic {locale_adj} street scene in {locale_city} with a street lamp pole in foreground. The uploaded image is displayed on two vertical banner flags hanging from brackets on the pole. Flags have slight fabric drape. Background: {locale_adj} urban street, cars, bicycles, buildings. Daytime. Looks like real printed fabric banners."

**Airport Arrival Hall:**
"Create a photorealistic airport arrival corridor. The uploaded image is displayed as a series of backlit lightbox advertisements along the corridor wall. Terminal walkway, moving walkway, flight information screens, travelers with luggage. Bright airport lighting. The lightboxes glow evenly."

**Rooftop Billboard:**
"Create a photorealistic dusk scene. The uploaded image is displayed on a classic rooftop billboard with steel frame structure. Highway in foreground with car light trails. Dusk sky gradient (orange to deep blue). The billboard is illuminated by spotlights. Urban skyline in background."

### Step 5: Batch Mode (default 7 outputs)

AI auto-selects the best combinations. Each output uses different photo + different style + different color scheme.

| # | Output | Photo | Style | Scene | Ratio |
|---|--------|-------|-------|-------|-------|
| 1 | Poster Design (vertical) | Photo A | Auto (from outfit/theme color) | — | 3:4 |
| 2 | → Scene Composite | #1 result | — | Commercial Building Facade | 3:4 |
| 3 | Poster Design (vertical) | Photo B | Vibrant Pop (yellow/green) | — | 3:4 |
| 4 | → Scene Composite (elevator) | #1 + #3 | — | Elevator Door Stickers | 9:16 |
| 5 | Poster Design (wide collage) | Photo C + refs:[D,E,F...] | K-style Collage (theme color mix) | — | 16:9 |
| 6 | → Scene Composite | #5 result | — | Subway Wide Banner | 16:9 |
| 7 | Poster Design (vertical) | Photo F | Premium Editorial (silver-blue) | — | 3:4 |

**Photo diversity rules:**
- Each poster design uses a DIFFERENT photo as primary `image` (A ≠ B ≠ C ≠ F)
- Each poster uses a DIFFERENT color scheme — derive first color from idol's outfit/theme, then vary across spectrum
- Each poster uses a DIFFERENT style
- Elevator doors special: left and right doors show different poster designs (#1 and #3)
- Subway Wide Banner (#5): pass ALL remaining photos in `referenceImages` for multi-photo collage
- If only 1-2 photos: reuse with different style/color/cropping per item

### Step 6: Campaign Showcase Page (全套宣传展示图)

After all scene mockups are generated, create a **campaign showcase long-image** for each scene location. This is NOT a simple collage — it's a professional fan project promotional page.

Call `generate_image` for each showcase page with:
- referenceImages: the scene mockup(s) for this location
- skill: creative
- aspectRatio: 9:16 (tall vertical format)
- editPrompt: "Create a professional fan support campaign showcase page, tall vertical long-image format. Unified {theme_color} background. Layout from top to bottom: (1) Decorative title banner: '{event_name}' in elegant script/display font + 'Part {N}' label + idol name in {idol_lang} + decorative flourishes. (2) Scene location title: '{scene_name}' in bold, with specs like dimensions. (3) A short poetic/emotional blessing paragraph in Chinese (2-3 sentences about supporting the idol). (4) The scene mockup photo displayed prominently with slight tilt and shadow, showing the poster in its real-world location. (5) Project info section: '投放时间: {dates}' and '投放地点: {location}' in clean info-card style. (6) Fan club credit '{fan_club}' at bottom. Premium graphic design quality, magazine-editorial layout with breathing space between sections. {theme_color} as dominant color throughout."

### Step 7: Review and Iterate

Display all outputs grouped: poster designs → scene mockups → showcase pages. User can request:
- Different scene, style, or color scheme for any item
- Different photo allocation
- Additional scenes from the scene library
- Adjustments to showcase page content

## Rules

### Photo Fidelity (TOP PRIORITY)
- The person's photo displayed on any poster/screen/banner must be EXACTLY as in the original — do NOT modify face, body, hair, outfit
- useOriginalAsReference: true for ALL calls
- If the person's appearance changes, discard and retry
- Design elements (text, decorations) go AROUND the photo only

### Photo Usage
- Accept up to 7 photos. Each batch item should use a DIFFERENT photo as primary `image` — rotate through all uploads
- For collage items (Subway Banner): pass ALL photos in `referenceImages`, prompt requests multi-photo layout
- If only 1 photo: reuse is acceptable
- Multi-photo layout rules:
  - 1 photo: hero image occupying 60%+ of poster area
  - 2-3 photos: 1 main + others as decorative small circular/framed insets
  - 4-7 photos: collage layout with varied sizes, auto-recommend K-style Collage

### Poster Design Quality
- Text must be LARGE, bold, high-contrast — readable at building scale
- Typography: 2+ layers (hero name + supporting text + small credit)
- No flat backgrounds on posters — use gradients, patterns, textures
- Decorations must not cover the person's face
- Each item in a batch should use a different color scheme for variety
- Color depth: use 3-4 shades within the theme color family, not a single flat color

### Scene Composite Quality
- Perspective must be correct — poster conforms to building surface angle and distortion
- Lighting interaction — at night, LED screen light maps onto surrounding ground/walls
- Realistic environment — include pedestrians, vehicles, other signage for lived-in feel
- Poster edge treatment — must look like a real installed/displayed advertisement, not Photoshopped
- Scale must be believable — poster proportions match the architectural surface
