---
name: fan-merch
description: >
  Generate fan merchandise designs from photos — phone cases,
  acrylic standees, keychains, banners, badges, stickers and more.
  Batch or single-item mode with consistent theme color.
allowed-tools: generate_image analyze_image
metadata:
  makaron:
    icon: "🎀"
    color: "#E88ABF"
    tags: [fan, merch, idol, support, design]
    tipsEnabled: true
    tipsCount: 4
    faceProtection: default
---

# Fan Merch Generator

**⚠️ BEFORE YOU DO ANYTHING: The user's attached images ARE the input photos. Use them directly. Do NOT say "I don't see any photos" or ask the user to upload. If there are images in the conversation, those are your photos. Start working immediately.**

Generate fan merchandise/support material designs from idol or
character photos. Produces designs with consistent theme color,
decorative elements, and text overlays.

## Design Styles

Analyze the photos and choose the most fitting style, or let user pick:

| Style | Key Traits | Best For | editPrompt Keywords |
|-------|-----------|----------|-------------------|
| Magazine Cover | Editorial layout, bold serif title, fashion magazine framing (Vogue/Elle/GQ), multi-font typography, script name as background element | Poster | "fashion magazine cover layout, bold serif title + elegant script name as decorative background text, multi-layered typography with at least 3 font sizes, high-end print design, {theme_color} gradient background with blurred photo underlayer" |
| Dreamy Romantic | Lace borders, dried flowers, butterflies, soft pastel gradient, vintage frames, pearl chain accents, ribbon bows, stamp/polaroid inset photos | Phone case, keychain, postcard | "dreamy romantic aesthetic, soft lace doily borders, dried flower petals, butterfly motifs, pearl chain accents, satin ribbon bows, pastel gradient tones, small polaroid inset photo, delicate stamp-edge frame" |
| Y2K Retro | Pixel elements, retro photo frames, nostalgic color grading, chrome/metallic outlined text, old-school stickers, halftone dots, rainbow gradients | Phone case, keychain, sticker | "Y2K retro aesthetic, pixel art accents, chrome metallic outlined text, nostalgic warm color grading, retro frame, halftone dot overlay, rainbow gradient accents, sticker-bomb collage feel" |
| Minimal Fresh | Generous white space, thin hairline borders, clean sans-serif typography, muted tones, subtle shadow depth, geometric accent shapes | Phone case, standee, ticket | "minimalist clean design, generous white space, thin hairline border, modern sans-serif typography, muted pastel tones, subtle drop shadow for depth, small geometric accent shapes" |
| Cute Pop | Bright saturated colors, cartoon mascots, bubble/rounded text with outlines, sticker-bomb feel, speech bubbles, candy/lollipop motifs, star bursts | Banner, sticker | "cute pop art style, bright saturated colors, cartoon mascot elements, bubbly rounded outlined text, speech bubble callouts, candy and lollipop motifs, star burst accents, playful sticker collage" |
| Dark Cool | Dark/black background, neon glow accents, sharp geometric lines, metallic chrome textures, holographic shimmer, bold sans-serif typography | Poster, badge | "dark moody aesthetic, black background, neon glow accents in {theme_color}, metallic chrome textures, holographic shimmer effect, bold condensed sans-serif typography, sharp geometric lines" |
| Japanese Film | Film grain texture, soft warm light leak, muted desaturated tones, handwritten Japanese-style caption, washi tape accents, polaroid frame, analog camera graphic | Phone case, standee, postcard | "Japanese film photography style, analog film grain texture, soft warm light leak overlay, muted desaturated tones, handwritten caption, washi tape accent, polaroid frame inset, vintage analog camera graphic element" |
| K-fan Support | Korean handwritten font feel, soft pink/purple gradient palette, hearts and stars, angel wings, idol birthday cafe aesthetic, lace doily, pearl accents, multi-photo collage with different frame shapes | Banner, poster | "Korean fan support style, soft pink-purple gradient palette, Korean handwritten font feel, hearts and stars and angel wing motifs, birthday cafe event aesthetic, lace doily underlayer, pearl chain accents, multi-photo creative collage with circle and square and stamp-shaped frames" |
| Vintage Newspaper | Old newspaper clipping layout, sepia/aged paper texture, typewriter font headlines, torn paper edges, stamp marks, vintage ad aesthetic | Banner, poster | "vintage newspaper clipping aesthetic, aged yellowed paper texture, typewriter serif headlines, torn irregular paper edges, postal stamp marks, retro classified ad layout, ink splatter accents" |
| Holographic Futuristic | Iridescent/holographic gradients, glass morphism elements, frosted translucent panels, futuristic sans-serif, chrome reflections | Badge, poster | "holographic iridescent gradient background, glass morphism frosted panels, chrome metallic reflections, futuristic clean sans-serif typography, prismatic rainbow light accents, translucent layered design" |
| Watercolor Art | Soft watercolor paint bleed edges, hand-painted floral illustrations, calligraphy text, natural organic shapes, art paper texture | Standee, keychain, postcard | "soft watercolor paint aesthetic, color bleeding at edges, hand-painted floral illustrations, elegant calligraphy text, natural organic shapes, textured art paper background, botanical accents" |
| Dessert Cafe | Bakery/patisserie theme, cookie/cake decorative motifs, warm cream/brown palette, recipe card layout, cute food illustrations | Badge, fridge magnet | "sweet dessert cafe aesthetic, bakery patisserie theme, cookie and cake decorative motifs, warm cream and brown palette, recipe card layout feel, cute food illustrations, lace doily napkin underlayer" |
| Neon Street | Urban street art vibe, neon sign text on dark/brick background, graffiti accents, gritty texture, bold color pops | Banner, poster | "urban neon street aesthetic, glowing neon sign text on dark brick wall background, graffiti spray paint accents, gritty concrete texture, bold saturated color pops, street photography vibe" |
| Celestial Dreamy | Night sky/galaxy background, constellation line art, moon and star motifs, silver/gold metallic text, ethereal glow | Phone case, standee, poster | "celestial night sky aesthetic, deep blue-purple galaxy gradient background, constellation line art, crescent moon and star motifs, silver metallic text with ethereal glow, dreamy cosmic dust particles" |

**Style selection logic — per-item, not per-batch:**

Each item in the batch gets its own style chosen by crossing **photo mood** × **item character** (see Item Character column in batch table). Do NOT use the same style for all items.

1. If user specifies a style → apply it only to that item, pick different styles for the rest
2. If user doesn't specify → for each item, pick the best-fit style from the full 14-style library by considering both the photo mood and what suits that item's physical nature
3. The 7 items should use **at least 4 different styles** — visual diversity is the goal
4. **Theme color is the unifying thread** — styles differ but the color palette stays consistent across all items

## Workflow

### Step 1: Collect Input

Images attached in the user's message ARE the input photos — use them directly, do NOT ask the user to upload again. Only ask for missing **required** info that cannot be inferred (usually just the name). If the name can be inferred from context, proceed immediately without asking.

**Required:**
1. Photos — 1-9 images of the person. These come from the user's attached/pasted images in their message. NEVER say "no photos uploaded" — if you can see images in the conversation, those are the photos.
2. Name — the person's name (for text overlays)

**Optional (AI fills if omitted):**
3. Theme color — e.g. "purple", "mint green", "#E88ABF"
   - If omitted: analyze photos and pick a flattering color
4. Date — birthday or event date, e.g. "0309"
5. Event name — e.g. "Happy Taeyeon Day", "Garden Voice"
   - If omitted: generate one from the name
6. Slogan — support phrase, e.g. "All for Taeyeon"
   - If omitted: generate a short one
7. Style preference — one of the styles above, or "auto" (default)

### Step 2: Analyze Photos

Use your vision capability to look at the user's attached photos and understand:
- Face position and composition
- Outfit/concept style (for auto style selection)
- Best photos for each merch type (close-up → badge, full body → banner)
- Color palette for theme matching

You can see the images directly in the conversation — analyze them visually, no tool call needed for this step.

### Step 3: Generate Merch Designs

#### Batch Mode (default) — 7 items

Generate the following 7 items in order:

| # | Item | Skill | Aspect Ratio | Item Character | Focus |
|---|------|-------|-------------|----------------|-------|
| 1 | Fridge Magnet | creative | 1:1 | Small, cute, collectible — suits playful/warm/cozy styles | Product-style fridge magnet in a varied shape (round, heart, star, cloud, die-cut) — shape matches the chosen style |
| 2 | Phone Case | creative + captions | 9:16 | Everyday carry, sleek product — suits clean/editorial/atmospheric styles | Tall phone case mockup: person photo on case back, camera cutout, name typography, 3D angled product shot |
| 3 | Acrylic Standee | creative | 2:3 | Display piece, stage presence — suits dramatic/ethereal/artistic styles | Full/half-body cutout on transparent acrylic base, holographic edge glow, floating decorations |
| 4 | Keychain | creative | 1:1 | Tiny accessory, charm-like — suits delicate/retro/cute styles | Face photo in shaped pendant (circle/heart/star), metal ring + clasp + mini charm dangles |
| 5 | Hand Banner | creative + captions | 3:1 | Event/concert use, loud & bold — suits high-energy/collage/street styles | Wide banner with creative multi-photo collage layout |
| 6 | Circle Badge | creative | 1:1 | Pin/button, graphic punch — suits bold/contrast/texture-heavy styles | Circular composition with style-matched border |
| 7 | Q-version Sticker | wild | 1:1 | Cartoon/chibi transformation | Cute chibi/cartoon version |

#### Single-Item Mode

User specifies which item to generate. Additional items beyond the default 7:

| Item | Skill | Aspect Ratio | Description |
|------|-------|-------------|-------------|
| Postcard | creative + captions | 4:3 | Photo with decorative overlay, message area |
| Ticket | captions | 16:9 | Entry ticket with name, date, event info |
| Menu Card | captions | 3:4 | Cafe menu style with themed food names |
| Calendar Card | creative + captions | 3:4 | Monthly calendar with different photos |
| Fridge Magnet | creative | 1:1 | Small square design with photo and decorations |
| Photo Card (3-part) | enhance / creative+captions / creative | 3:4, 3:4, 3:2 | Front (enhanced photo) + Back (design side, no person) + Flat Lay display |

### Step 4: Generate Each Item

**Photo allocation strategy — use ALL uploaded photos, not just one:**

When user uploads N photos (N > 1), distribute them across items AND within items:

| Item | image (main) | referenceImages | Why |
|------|-------------|-----------------|-----|
| Fridge Magnet | Best close-up (photo A) | [photo B, photo C] for inset/background | Multi-photo enriches the design |
| Phone Case | Best half-body portrait (photo B) | [photo A] for optional small inset | Phone case is a product shot — 1 clear main photo |
| Acrylic Standee | Best full-body (photo C) | [photo A, photo B] for small background elements | Standee needs full/half body for the cutout figure |
| Keychain | Best face close-up (photo D or A) | — | Small format, single photo is cleanest |
| Hand Banner | Best half/full body (photo E or C) | [photo A, photo B, photo D, photo F...] — pass ALL remaining photos | Banner is a multi-photo collage, needs maximum photos |
| Circle Badge | Second-best face close-up (photo F or B) | [photo D] for small inset | Badge can have a small secondary photo |
| Q-version Sticker | Most expressive (photo G or best) | — | Single photo is fine |

**Key rules:**
- **CRITICAL: Always use the user's ORIGINAL uploaded photos as `image` input for every generate_image call. NEVER pass a previously generated result as the `image` for the next item.** Each merch item must be generated from the original photo, not from another merch design. If you just generated a fridge magnet, the next phone case call must use the original photo — NOT the fridge magnet result.
- Rotate primary photo (`image`) across items — do NOT use the same photo as `image` for every item
- For **Hand Banner**: pass as many photos as possible (up to 7) in `referenceImages` — the prompt instructs a multi-photo collage, and the model needs access to all photos to compose it
- For **Fridge Magnet**, **Circle Badge**, and **Acrylic Standee**: pass 1-2 extra photos in `referenceImages` for optional inset/background use
- If user uploads only 1 photo: reuse is acceptable, skip multi-photo collage instructions

For each item, call `generate_image` with:
- image: the allocated **original uploaded** photo for this item (see table above) — NEVER a previously generated result
- referenceImages: the allocated **original uploaded** photos (see table above)
- editPrompt: combine the item template + chosen style keywords from the Style table
- **MANDATORY in every editPrompt:** append "IMPORTANT: Do NOT modify the person in the photo — keep their face, body, hair, outfit, and all physical features exactly as in the original. Only add decorative elements, borders, backgrounds, frames, and text around the person. The person is the untouchable core of the design."
- skill: as specified in the table above
- aspectRatio: as specified in the table above
- useOriginalAsReference: true

**editPrompt templates (combine with style keywords):**

**Fridge Magnet:** "Design a collectible fridge magnet as a real product shot. First pick a shape that fits the style — do NOT always use a square. Shape options: round, rounded-square, heart, star, cloud, die-cut silhouette, or irregular blob. The magnet should look like a physical object with visible thickness/edge, subtle shadow on the surface beneath it, and a slightly 3D feel. Feature the person's photo as the main visual, framed by {theme_color} decorative border matching the chosen shape. Add '{name}' in a font style that matches the design aesthetic, '{date}' as a small accent. {style_keywords}. Background: soft clean surface (marble, wood, pastel flat-lay) with natural shadow to sell the product feel. The magnet shape, border style, and decorative accents should all follow the chosen design style — e.g. Dreamy Romantic → heart/cloud shape with lace edge; Dark Cool → die-cut silhouette with neon glow edge; Y2K Retro → star/blob shape with chrome border; Minimal Fresh → clean round with thin hairline border; Cute Pop → irregular bubbly shape with candy-color outline."

**Phone Case:** "Design a premium fan phone case mockup. Show a smartphone case (slightly angled 3D perspective with subtle shadow) featuring the person's photo as the main visual on the case back. The case design uses a {theme_color} color scheme with layered decorative elements: '{name}' in stylish typography across the top or bottom of the case, '{date}' as a small accent number, decorative motifs (hearts, stars, ribbon bows, or floral accents) framing the photo area. Add a camera cutout hole area at the top of the case back. The phone case should look like a real product — glossy or matte finish, rounded corners, visible edge thickness. {style_keywords}. Background: soft gradient or marble surface with gentle shadow beneath the phone case. Premium fan merchandise product photography feel."

**Acrylic Standee:** "Create an acrylic standee fan merchandise design. The person should appear as a full/half-body cutout figure mounted on a transparent acrylic base/stand at the bottom. Add a decorative {theme_color} border glow or outline around the person's silhouette — like a die-cut edge with subtle holographic or glitter shimmer effect. Small decorative accents floating around the figure: stars, hearts, sparkles, tiny ribbon bows, or constellation dots. '{name}' engraved or printed on the transparent acrylic base in elegant font. The acrylic material should look clear/translucent with realistic light refraction and subtle rainbow prismatic edge effects. {style_keywords}. Background: clean soft gradient or blurred bokeh to make the standee pop as a product shot. The standee should look like a real collectible acrylic display piece."

**Keychain:** "Design an adorable fan keychain merchandise piece. Feature the person's face/upper body photo inside a decorative shaped frame — choose one: circular, heart-shaped, star-shaped, or cloud-shaped pendant. The frame has a {theme_color} enamel-style border with metallic gold or silver edge trim. A small metal keychain ring and lobster clasp attached at the top, with a short chain link connecting to the pendant. Add tiny charm dangles hanging from the ring: mini heart, star, or initial letter '{name[0]}' charm. '{name}' in tiny elegant script on the back or bottom edge of the pendant. {style_keywords}. Sprinkle small decorative elements: glitter dots, micro hearts, tiny stars near the pendant. Background: soft pastel or white surface with gentle product shadow. The keychain should look like a real metal-and-acrylic collectible accessory."

**Hand Banner:** "Create a wide horizontal fan support banner with creative multi-photo collage layout. Use the main image AND all reference images to create a collage — feature one large hero photo (the main image) + use every reference image as smaller inset photos in polaroid/circle/square frames, overlapping and layered at different sizes. '{name}' in HUGE bold outlined/3D text spanning the full width as a background design element (English or Korean name). Weave '{date}', '{slogan}' in smaller contrasting fonts between the photos. {style_keywords}. Background: {theme_color} gradient with torn paper edge effect at bottom. Add decorative accents: ribbon bows, stars, hearts, speech bubbles. NOT a simple left-photo-right-text split — photos and text should interweave in a dynamic creative collage. Text must NOT cover the person's face. IMPORTANT: use ALL provided photos, not just one."

**Circle Badge:** "Create a circular badge design. Center the person's face photo with a {theme_color} halftone dot pattern overlay for texture. Decorative ring border: striped pattern or scalloped edge in {theme_color} tones. Add scattered decorative elements around the face: speech bubble saying 'Hello!' or a cute phrase, mini hearts, stars, lollipop or candy motif, tiny ribbon bow. '{name}' in bubbly script font curved along the bottom, '{date}' numbers (like '03' and '09') placed as small accent badges. {style_keywords}. Sweet dessert-cafe aesthetic. The badge should look like a real collectible pin."

**Q-version Sticker:** "Transform this person into an adorable chibi/cartoon character. Exaggerated large head, small body, cute kawaii expression. Simple {theme_color} background. Sticker-ready with clean edges."

### Step 5: Review and Iterate

After all items are generated:
1. Display all generated designs to the user
2. Ask if any items need re-generation or style adjustment
3. User can request a different style for specific items
4. If user wants changes, regenerate with adjusted style/prompts

### Step 6: Save Results (optional)

Ask user:
- Save all designs locally?
- Target directory (suggest `fan-merch-output/`)

## Rules

### Core
- Always maintain consistent theme color across ALL items
- **Person preservation (TOP PRIORITY):** The uploaded person photo is sacred — do NOT modify, distort, beautify, or regenerate the person's face, body, hair, outfit, or any part of their appearance. The person must look exactly like the original photo. Only add decorative elements, borders, backgrounds, and text AROUND the person — never alter the person themselves. If a generation result changes the person's appearance in any way, discard and retry
- useOriginalAsReference: true for all generate_image calls
- Text must include the person's name on every item
- Do NOT generate items the user didn't request in single-item mode
- If a generation result doesn't preserve the person's likeness, discard and retry
- Slogan/text language: if user specifies the idol's nationality, use that language (e.g. Korean idol → Korean text, Japanese idol → Japanese text). Otherwise default to English
- Style diversity: each item should use its own best-fit style chosen by crossing photo mood × item character (see Item Character column). The theme color is the unifying element — styles should differ but color palette stays consistent. Aim for at least 4 different styles across the 7 items. Do NOT use the same style for every item

### Photo Usage
- Accept up to 9 photos. Each item should use a DIFFERENT best-fit photo as the primary image — do NOT reuse the same photo across all items. Selection logic:
  - Close-up/selfie → keychain, badge, sticker, fridge magnet
  - Half-body/portrait → phone case, acrylic standee
  - Half-body/full-body → banner
  - Most expressive/dynamic photo → sticker (Q-version)
  - If only 1 photo provided, reuse is acceptable
  - Up to 7 photos can be passed as referenceImages per call for multi-photo compositions
- Multi-photo collage: items like banners should use 3+ photos at different sizes (one hero photo + smaller inset photos in varied frame shapes). Avoid single-photo-only layouts when multiple photos are available

### Design Quality
- Typography layering: every item (except Q-version sticker) must use at least 2 contrasting font styles/sizes — e.g. large decorative script name + small clean sans-serif date/info
- No flat solid backgrounds: always use gradients, blurred photo underlays, subtle texture patterns (dots, stripes, bokeh), or layered color washes
- Rich decorative elements: include style-appropriate ornaments (ribbon bows, pearl chains, lace trim, dried flowers, stars, hearts, speech bubbles, tape/pin accents). Decorations should be plentiful but balanced — premium feel, not cluttered
- Text placement: text can go anywhere creatively (including behind the person via cutout layering) but must NEVER cover the person's face
- Color depth: use 3-4 shades within the theme color family (e.g. for pink: rose + blush + cream + gold accent) rather than a single flat color
