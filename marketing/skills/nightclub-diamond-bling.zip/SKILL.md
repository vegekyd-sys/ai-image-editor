---
name: nightclub-diamond-bling
description: >
  Transform any person into a nightclub diamond bling portrait — dramatic neon purple/blue club lighting,
  iced-out diamond grillz, luxury watches, Cuban link chains, chunky diamond rings, and a confident
  party vibe. Candid nightlife photography with hip-hop aesthetic.
allowed-tools: generate_image analyze_image
metadata:
  makaron:
    icon: "💎"
    color: "#7B2FBF"
    referenceImages:
      - assets/reference-original.jpg
      - assets/reference-generated.jpg
    tags: [style, nightlife, bling, portrait, jewelry]
    modelPreference: [gemini]
    faceProtection: strict
    defaultAspectRatio: "4:5"
---

# Nightclub Diamond Bling Portrait

Transform any person's photo into a luxurious nightclub diamond bling portrait. The style replicates candid nightlife photography with a hip-hop / bling culture aesthetic.

Reference Image 1 (reference-original.jpg): The original style template — blonde woman at nightclub.
Reference Image 2 (reference-generated.jpg): A generated example showing the style applied to a different person.

## Core Visual Elements

### Lighting
- Primary: Dramatic neon purple and blue club lighting
- Cool-toned highlights on face and jewelry
- Deep blue/purple ambient background glow
- Slight overexposure on jewelry to simulate flash catch
- Overall dark moody atmosphere with selective illumination

### Jewelry & Accessories (MUST include ALL)
- **Diamond grillz** on teeth (upper and lower, fully iced out, visible when smiling/laughing)
- **Iced-out luxury watch** on wrist (large face, fully encrusted with diamonds)
- **Cuban link bracelet** (chunky, diamond-studded, next to the watch)
- **Multiple large diamond rings** on fingers (at least 3-4 rings, oversized stones)
- All jewelry is silver/platinum tone with brilliant white diamond sparkle

### Pose & Expression
- Close-up portrait, slightly below eye level (looking slightly up at subject)
- Left fist raised near face, showcasing jewelry prominently
- Joyful laughing expression, mouth open showing grillz
- Confident, celebratory energy

### Clothing
- Black turtleneck/high-neck top
- Simple, dark clothing to let jewelry be the focal point

### Image Quality & Feel
- Slightly grainy, candid quality (like phone camera flash at a party)
- NOT overly polished or studio-perfect
- Diamonds catch light brilliantly with sparkle and reflections
- Shallow depth of field, background soft and dark

## Rules

1. **Face preservation is CRITICAL**: When editing a person's photo, preserve their exact face shape, eyes, nose, skin texture, and all facial features. Only add grillz to teeth and adjust lighting on face.
2. **Always reference both style images** to maintain consistency in jewelry detail, lighting color temperature, and overall mood.
3. **Jewelry must be photorealistic** — real diamonds catching real light, not cartoon or CGI-looking.
4. **Background must be dark nightclub** — deep blue/purple ambient light, no bright or outdoor backgrounds.
5. **The fist-raised pose** is signature — if the source photo allows, guide the subject into this pose. If not possible, ensure jewelry is prominently visible on hands/wrists.
6. **Grain and candid feel** — add subtle noise/grain to maintain the authentic nightlife photo aesthetic. Avoid clean studio looks.
7. **Color palette**: Dominant purple (#7B2FBF), deep blue (#1a1a6e), cool silver (#C0C0C0), diamond white sparkle. No warm tones except slight skin warmth.

## Prompt Template

When generating, use this as your base and customize per the user's photo:

"Close-up portrait in a dark nightclub setting. [Subject description from user's photo]. Wearing a black turtleneck. Left fist raised near face showcasing an iced-out diamond luxury watch, chunky Cuban link diamond bracelet, and multiple large diamond rings on every finger. Mouth open in a joyful laugh revealing full diamond grillz on upper and lower teeth. Dramatic neon purple and blue club lighting casting cool-toned highlights on face and jewelry. Dark background with deep blue and purple ambient nightclub light. Diamonds and jewelry catching light brilliantly with sparkle and reflections. Slightly grainy candid quality like a phone flash photo at a party. Confident, flashy, celebratory mood. Candid nightlife photography, hip-hop bling aesthetic."
