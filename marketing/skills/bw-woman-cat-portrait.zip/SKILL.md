---
name: bw-woman-cat-portrait
description: >
  Generate intimate black and white portraits of a woman and her cat
  in a nose-to-nose touching pose — warm indoor setting, macro close-up feel,
  emotional connection between human and feline.
allowed-tools: generate_image analyze_image
metadata:
  makaron:
    icon: "🐱"
    color: "#4A4A4A"
    referenceImages:
      - assets/woman-cat-reference.jpg
    tags: [portrait, cat, black-and-white, intimate, pet]
    modelPreference: [gemini]
    faceProtection: strict
    defaultAspectRatio: "9:16"
---

# Black & White Woman & Cat Portrait (女人与猫黑白鼻尖触碰照)

Generate intimate, emotionally rich black and white portraits of a woman sharing a tender nose-touch moment with her cat.

## Visual Style

### Composition & Framing
- **Aspect ratio**: 9:16 vertical
- **Framing**: Tight close-up / macro feel — faces and the nose-touch point fill 80%+ of frame
- **Subject placement**: Woman on the LEFT, cat on the RIGHT (consistent layout)
- **Side profile**: Both subjects shown in profile or three-quarter view, facing each other
- **Depth of field**: Shallow — background softly blurred, sharp focus on the nose-touch contact point

### Black & White Treatment
- **Rich, cinematic black and white** — not flat, but with deep shadows and soft highlights
- **Shadow-dominant**: Unlike the couple portrait (white bg), this style uses DARK backgrounds and moody shadows
- **Tonal emphasis on textures**: Cat fur, knit sweater fabric, skin pores, whiskers — all should be tactile and detailed
- **Subtle vignette**: Natural light falloff toward edges, drawing focus to center

### Lighting
- **Window light** from behind/above: Soft, natural, diffused daylight — the primary light source
- **Backlight rim**: Light catching cat's fur edges and woman's hair for separation
- **Rembrandt-style shadows**: Gentle shadow play on the woman's face, creating depth
- **Indoor ambient**: Feels like a quiet room on an overcast afternoon — soft, contemplative light

### Background & Setting
- **Dark, blurred interior**: Suggestion of furniture (vintage chair, window frame) in soft bokeh
- **Window visible**: A window in the background, overexposed to white, providing the light source
- **NOT studio white**: This is a home environment — warm, lived-in, real
- **Muted but rich**: The background should feel like an old European apartment

### The Nose-Touch Moment
- **THE signature gesture**: Woman's nose gently touches cat's nose — the emotional centerpiece
- **Woman's expression**: Eyes closed, serene smile, complete peace and tenderness
- **Cat's posture**: Alert but trusting — ears forward, whiskers splayed, body relaxed in woman's arms
- **Cat breed reference**: Siamese/colorpoint — dark face mask, ears, and paws with lighter body
- **Whiskers**: Must be sharp, detailed, catching the light — a key textural element

### Wardrobe & Styling
- **Woman**: Dark oversized knit sweater (粗针织毛衣) — chunky texture, crew/mock neck
- **Hair**: Pulled back naturally, not styled — casual, intimate, at-home feeling
- **No jewelry**: Simple, unadorned — the focus is the human-animal connection
- **Natural skin**: Freckles, natural texture visible — no retouching, no makeup look

## Rules
- Always reference the provided woman-cat portrait for pose, lighting, and mood consistency
- The nose-touch is SACRED — it must be the clear focal point of every image
- This is NOT a pet photo — it's an **art portrait** about the bond between human and animal
- Lighting should feel **natural and found**, not studio-lit
- Cat must look like a **real cat** with real cat behavior — alert eyes, natural posture, NOT cartoonish
- The emotional tone is "quiet intimacy, trust, gentleness" (安静的亲密、信任、温柔)
- Sweater texture is a key visual element — the chunky knit pattern should be visible and tactile
- When generating variations, keep the nose-touch and side-profile composition but vary: cat breed, sweater style, background details, exact head angle
- Cat whiskers must be SHARP and detailed — they're a micro-detail that elevates the image
