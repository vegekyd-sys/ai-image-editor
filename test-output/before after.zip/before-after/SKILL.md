---
name: before-after
description: >
  Create a professional before/after side-by-side collage comparing the original photo
  and an edited version. Adds BEFORE/AFTER labels and a clean white divider line.
allowed-tools: generate_image analyze_image run_code
metadata:
  makaron:
    icon: "↔️"
    color: "#222222"
    referenceImages:
      - https://sdyrtztrjgmmpnirswxt.supabase.co/storage/v1/object/public/images/b8b676af-facd-42fa-9d98-ad205073d3b5/workspace/skills/before-after/assets/ref.jpg
    tags: [collage, comparison, before-after]
    tipsEnabled: false
---

# Before / After Collage

Create a side-by-side comparison image with the original photo on the left (BEFORE)
and the edited version on the right (AFTER), separated by a white divider line.

## Layout
- Left panel: original / BEFORE image
- Right panel: edited / AFTER image
- Center: 6px white vertical divider
- Bottom strip: black bar with "BEFORE" and "AFTER" labels in bold white text

## Rules
- Both panels must be the same height
- Labels are centered below each panel in uppercase, bold, letter-spacing 4px
- Output as high-quality JPEG (92%+)
- Use `run_code` with `sharp` for pixel-perfect compositing — do NOT use generate_image for this task

## Reference
The reference image shows an example collage output using this skill.